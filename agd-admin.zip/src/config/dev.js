const dev = {
  API_BASE_URL: process.env.REACT_APP_API_ENDPOINT
  };
  
  export default dev;