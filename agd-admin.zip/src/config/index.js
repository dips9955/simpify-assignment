import dev from "./dev";

const config = dev;

export default {...config};
