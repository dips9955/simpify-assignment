import React, { useState, useEffect } from "react";
import { Modal } from "react-bootstrap";
import axios from "axios";
import config from "../../config/index";
import {  handleGetlistError } from "../../constants/error";
import moment from "moment";
import { ENROLSTATUS } from "../../constants/enrolStatus";
import { BADGE } from "../../constants/bagde";
import { Spinner } from "../spinner/spinner";
import { withTranslation } from "react-i18next";
const { API_BASE_URL } = config;

export const SummaryModal = props => {
  const [enrolCount, setEnrolCount] = useState([]);
   const [agdCount, setAgdCount] = useState([]);
   const [onlineCount, setOnlineCount] = useState([]);
   const [typeCount, setTypeCount] = useState([]);
  const [loader, setLoader] = useState(false);

  useEffect(() => {
      debugger
    props.show &&
    setLoader(true);

      axios({
        method: "post",
        url: API_BASE_URL + "participantSummary",
        headers: {
          "content-type": "application/json",
          accept: "application/json",
          email: atob(localStorage.getItem("email")),
          lastSessionId: atob(localStorage.getItem("lsi")),

          Pragma: "no-cache"
        },
        data: {
          meetingId: atob(localStorage.getItem("meetingId"))
        }
      })
        .then(response => {
          console.log("c",response.data.participantSummary);
          setEnrolCount(response.data.participantSummary.enrolStatusDto);
          setAgdCount(response.data.participantSummary.agdUserDto);
          setOnlineCount(response.data.participantSummary.loginToGmDto);
          setTypeCount(response.data.participantSummary.participantTypeDto);
          setLoader(false);

        })
        .catch(err => {
          handleGetlistError(err, props.Props);
        });
    return () => {
      console.log("unmount");
      setEnrolCount([])
      setAgdCount([])
      setOnlineCount([])
      setTypeCount([])
      setLoader(false)

    };
  }, [props.show]);

  const date = atob(localStorage.getItem("meetingDate"));
  const { t } = props.Props;
  return (
    <div>
      <Modal centered size="md" show={props.show} onHide={props.onHide}>
        <div class="modal-content">
          <Modal.Header closeButton>
            <h5 class="modal-title">
             
                <div class="mr-10">{atob(localStorage.getItem("meetingName"))}</div>
                <div class="ml-10">
                  {moment(new Date(parseInt(date))).format("MM/DD/YYYY")}
                </div>
             
            </h5>
          </Modal.Header>
          {loader ? (
              <div class="pager ">
                <div class="text-center mt-50 mb-50">
                  <Spinner height={60} width={60} visible={true} />
                  <br />
                  Please wait...
                </div>
              </div>
            ) : 
          <div class="modal-body">
            <div>
              <div class="top-marg">
                <div className="table-responsive">
                  <table class="table table-bordered">
                    <thead>
                      <tr class="bg-secondary text-white">

                        <th>{t("summary.field_1")}</th>
                        <th class="text-right">{t("summary.field_2")}</th>
                      </tr>
                    </thead>
                    <tbody>
                    { 
                       enrolCount.map(e => (
                        e.enrolStatus !=null && <tr>
                         <td>
                             {
                                 ENROLSTATUS.map(en=>(
                                     e.enrolStatus === en.id?
                                    <div> {en.status_name}</div>:<div></div>
                                 ))
                             }
                         </td>
                         <td class="text-right">{e.count}</td>
                     </tr>
                        ))
                    }
                    {
                         agdCount.map(a => (
                            a.agdUser ===true && <tr>
                             <td>
                             {t("summary.field_3")}
                             </td>
                             <td class="text-right">{a.count}</td>
                         </tr>
                            ))
                    }
                    {
                         onlineCount.map(o => (
                            o.loginToGm ===true &&<tr>
                             <td>
                             {t("summary.field_4")}
                             </td>
                             <td class="text-right">{o.count}</td>
                         </tr>
                            ))
                    }
                     {
                         typeCount.map(t => (
                            ( t.type===3 || t.type===7||t.type===11 )?<tr>

                             <td>
                             {
                                    BADGE.map(b=>(
                                      b.id===t.type? b.badge_frenchName :<div></div> 
                                    ))
                                } 
                             </td>
                             <td class="text-right">{t.count}</td>
                         </tr>:<div></div>
                         
                            ))
                    }
                     
                 
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                data-dismiss="modal"
                onClick={props.onHide}
              >
                Cancel
              </button>
            </div>
          </div>
          }
        </div>
      </Modal>
    </div>
  );
};
const summaryModal = withTranslation()(SummaryModal);
export default summaryModal;
