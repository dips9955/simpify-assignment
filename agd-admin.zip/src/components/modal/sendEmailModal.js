import React, {  useState, useEffect } from "react";

import { Modal } from 'react-bootstrap'
import axios from 'axios';
import config from "../../config/index";
import { handleError } from "../../constants/error";
import { toast } from "react-toastify";
import { ENROLOPERATORLEVEL } from "../../constants/operatorLevel";
import { Spinner } from "../spinner/spinner";
import { withTranslation } from "react-i18next";
const { API_BASE_URL } = config;



export  function SendEmailModal(props) {

 
const [loader, setLoader] = useState(false);
useEffect(() => {

  return () => {
    console.log("unmount");
  
      setLoader(false)
  };
}, [props.show]);
  const onEmailsend=()=>{
    debugger
    setLoader(true);

    axios({
      method: "post",
      url: API_BASE_URL + "verifyApi2?pageCode="+props.pageCode,
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        email: atob(localStorage.getItem("email")),
        lastSessionId: atob(localStorage.getItem("lsi")),
         
        Pragma: 'no-cache'
      },
      data: {
        id: props.participant.id,
        operatorId:localStorage.getItem("staffId"),
        enrolStatus: props.enrolStatus
      }
    })
      .then(response => {
        console.log(response.data);
        toast.success("Email envoyé avec jeton", {
          position: toast.POSITION.TOP_RIGHT,
          toastId: 4,
          autoClose: 3000
        });
        setLoader(false);

        props.onHide()

      })
      .catch((err) => {handleError(err,props.Props)
      });
  }
console.log(props.pageCode, props.enrolStatus)
const { t } = props.Props
    return (
        <div>
             <Modal
          centered
          size="md"
          show={props.show}
          onHide={props.onHide}
        >
          {loader ? (
              <div class="pager ">
                <div class="text-center mt-50 mb-50">
                  <Spinner height={60} width={60} visible={true} />
                  <br />
                  Please wait...
                </div>
              </div>
            ) : 
          <div class="modal-content">
            <Modal.Header closeButton>
              <h5 class="modal-title">
                <strong>{t("Send_an_email_to_the_participant.field_10")}</strong>
              </h5>
            </Modal.Header>
            <div class="modal-body">
              <div>
                <strong class="text-secondary">{t("Send_an_email_to_the_participant.field_1")} :</strong>   {props.participant.name}{" " } {props.participant.surname}
                <br />
                <strong class="text-secondary">{t("Send_an_email_to_the_participant.field_2")}:</strong> {props.participant.id}

                <br />
                <strong class="text-secondary">{t("Send_an_email_to_the_participant.field_3")}:</strong>{" "}
              {props.participant.agdUser === true ? "YES" : "NO"}
              <br />
            
              <strong class="text-secondary">{t("Send_an_email_to_the_participant.field_4")}:</strong>{" "}
              {ENROLOPERATORLEVEL.map(
                l =>
                  l.id === props.participant.enrolOpratorLevel && (
                    <span>{l.level}</span>
                  )
              )}
              <br/>
                <strong class="text-secondary"> {t("Send_an_email_to_the_participant.field_5")}:</strong>{" "}
              {props.participant.ordShares}
              <br />
              <strong class="text-secondary">{t("Send_an_email_to_the_participant.field_6")}:</strong>{" "}
              <span id="full-address">
                {props.participant.address}
              </span>
              <br />
              <strong class="text-secondary">{t("Send_an_email_to_the_participant.field_7")}:</strong>{" "}
              <span id="full-email">{props.participant.email}</span>
              <br />
              <strong class="text-secondary">{t("Send_an_email_to_the_participant.field_8")}:</strong>{" "}
              <span id="full-phone">{props.participant.mobilePhone}</span>
              <br />
              </div>
              <div class="top-marg">
              {t("Send_an_email_to_the_participant.field_9")}
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-warning" onClick={onEmailsend}>
                Confirm
              </button>
              <button
                type="button"
                class="btn btn-secondary"
                data-dismiss="modal"
                onClick={ props.onHide}
              >
                Cancel
              </button>
            </div>
          </div>
          }
        </Modal>
        </div>
    )
}
const sendEmailModal = withTranslation()(SendEmailModal);
export default sendEmailModal;