import React, {  useState, useEffect } from "react";
import { Modal } from "react-bootstrap";
import axios from "axios";
import config from "../../config/index";
import { Spinner } from "../spinner/spinner";
import "react-confirm-alert/src/react-confirm-alert.css";
import { FILETYPE } from "../../constants/fileType";
import { handleError, handleGetlistError } from "../../constants/error";
import { toast } from "react-toastify";
import { ENROLOPERATORLEVEL } from "../../constants/operatorLevel";
import { withTranslation } from "react-i18next";

const { API_BASE_URL } = config;

export function FileModalComponent(props) {
  const [fileList, setFileList] = useState([]);
  const [uploadedFile, setUploadedFile] = useState();
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileTypeD, setFileTypeD] = useState(4);
  const [loader, setLoader] = useState(false);
  const [error, setError] = useState();
  useEffect(() => {
    debugger;
    console.log("filemodal", props);

    props.show &&
      axios({
        method: "post",
        url: API_BASE_URL + "files/getList",
        headers: {
          "content-type": "application/json",
          accept: "application/json",
          email: atob(localStorage.getItem("email")),
          lastSessionId: atob(localStorage.getItem("lsi")),

          Pragma: "no-cache"
        },
        data: {
          participantsId: props.participant.id
        }
      })
        .then(response => {
          console.log(response.data.fileDtoList.documentPath);
          setFileList(response.data.fileDtoList);
        })
        .catch(err => {
          handleGetlistError(err, props.Props);
          setError("Fiche(s) pas retrouvé");
        });
    return () => {
      console.log("unmount");
      setFileList([]);
      setUploadedFile(null);
      setFileTypeD(4);
      setSelectedFile(null);
      setError(null);
      setLoader(false)

    };
  }, [props.show]);

  const handleDropdown = e => {
    setUploadedFile("");

    console.log("value", e.target.value);
    setFileTypeD(parseInt(e.target.value));
  };

  function onChange(e) {
    setUploadedFile("");
    setSelectedFile(e.target.files[0]);
  }
  // const onConfirm=()=>{
  //   debugger;
  //   //const list=props.participant
  //   // console.log("f",list.filter(f=>(f.enrolStatus===(1))).length)
  //   // console.log("fileTypeD",props.participant)
  //   if(selectedFile){
  //     if(fileTypeD===12 || fileTypeD===13){
  //         onFileUpload()
  //     }else if((fileList.filter(f=>(f.type ===(fileTypeD))).length)===0){
  //       onFileUpload()
  //     }
  //     else{
  //       fileList.map(f=>{
  //         console.log("f",f.type)
  //         if (f.type===parseInt(fileTypeD)){
  //           props.onHide
  //       (
  //         confirmAlert({
  //           title: 'The older file will be replaced',
  //           message: 'Do you want to confirm',
  //           buttons: [
  //             {
  //               label: 'Yes',
  //               onClick: () => onFileUpload()
  //             },
  //             {
  //               label: 'No',
  //             }
  //           ]
  //         })
  //       )

  //       }

  //     })

  //     }
  //   }else {
  //     setUploadedFile("please select a file before send. ");

  //   }
  // }

  const onFileUpload = () => {

    if (selectedFile) {
      const [mimetype, fileType] = selectedFile.type.split("/");

      if (
        selectedFile.type == "image/jpeg" ||
        selectedFile.type == "image/png" ||
        selectedFile.type == "application/pdf" ||
        selectedFile.type == "audio/mpeg" ||
        selectedFile.type == "video/mp4" ||
        selectedFile.type == "image/bmp"
      ) {
        var reader = new FileReader();
        reader.onload = e => {
          console.log(e.target.result);
          var fSize = selectedFile.size / 600000;

          console.log("mb", fSize.toFixed(2));
          if (selectedFile.size < 6000000) {
            setLoader(true);
            axios({
              method: "post",
              url: API_BASE_URL + "files/uploadFile",
              headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                email: atob(localStorage.getItem("email")),
                lastSessionId: atob(localStorage.getItem("lsi")),

                Pragma: "no-cache"
              },
              data: JSON.stringify({
                participantsId: props.participant.id,
                staffUserId: localStorage.getItem("staffId"),
                type: fileTypeD,
                name: selectedFile.name,
                mimetype: mimetype,
                fileType: fileType,
                documentPath: e.target.result
              })
            })
              .then(response => {

                console.log(response.data);
                toast.success("Document(s) téléchargé(s)", {
                  position: toast.POSITION.TOP_RIGHT,
                  toastId: 7,
                  autoClose: 3000
                });
                setLoader(false);

                props.onHide();
              })
              .catch(err => handleError(err, props.Props));
          } else {
            setUploadedFile(
              "Ce fichier est trop lourd à télécharger. La taille maximale de fichier autorisée est de 6MB. "
            );
          }
        };
        reader.readAsDataURL(selectedFile);
      } else {
        setUploadedFile(
          " Veuillez sélectionner un type de fichier valide (pdf, png, bmp, jpeg, mp3, mp4) avant de télécharger. "
        );
      }
    } else {
      setUploadedFile(
        " Veuillez sélectionner un fichier avant de télécharger."
      );
    }
  };

  console.log("file props", props.Props);
  const { t } = props.Props;

  return (
    <div>

      <Modal
        centered
        size="md"
        show={props.show}
        onHide={props.onHide}
      >
        <div class="modal-content">
          <Modal.Header closeButton>
            <h5 class="modal-title">
              <strong>{t("Download_view_files.field_15")}</strong>
            </h5>
          </Modal.Header>
          <div class="modal-body">
            <div>
              <strong class="text-secondary">{t("Download_view_files.field_1")}:</strong>{" "}
              {props.participant.name} {props.participant.surname}
              <br />
              <strong class="text-secondary">{t("Download_view_files.field_2")}:</strong> {props.participant.id}
              <br />
              <strong class="text-secondary">{t("Download_view_files.field_3")}:</strong>{" "}
              {props.participant.agdUser === true ? "YES" : "NO"}
              <br />
            
              <strong class="text-secondary">{t("Download_view_files.field_4")}:</strong>{" "}
              {ENROLOPERATORLEVEL.map(
                l =>
                  l.id === props.participant.enrolOpratorLevel && (
                    <span>{l.level}</span>
                  )
              )}
              <br />
              <strong class="text-secondary">
                {" "}
                {t("Download_view_files.field_5")}:
              </strong>{" "}
              {props.participant.ordShares}
              <br />
              <strong class="text-secondary">{t("Download_view_files.field_6")}:</strong>{" "}
              <span id="full-address">{props.participant.address}</span>
              <br />
              <strong class="text-secondary">{t("Download_view_files.field_7")}:</strong>{" "}
              <span id="full-email">{props.participant.email}</span>
              <br />
              <strong class="text-secondary">{t("Download_view_files.field_8")}:</strong>{" "}
              <span id="full-phone">{props.participant.mobilePhone}</span>
              <br />
            </div>
            {loader ? (
              <div class="pager  mb-10">
                <div class="text-center">
                  <Spinner height={60} width={60} visible={true} />
                  <br />
                  Téléchargement du document ...
                </div>
              </div>
            ) : (
              <div class="top-marg ">
                <div className="table-responsive">
                  <table
                    class="table table-bordered"
                    style={{ borderCollapse: "collapse", width: "100%" }}
                  >
                    <thead>
                      <tr class="bg-secondary text-white">
                        <th>{t("Download_view_files.field_9")}</th>
                        <th>{t("Download_view_files.field_10")}</th>
                        <th>{t("Download_view_files.field_11")}</th>
                        <th>{t("Download_view_files.field_12")}</th>
                      </tr>
                    </thead>

                    <tbody>
                      {fileList.length ? (
                        fileList.map(files => (
                          <tr class="text-center">
                            <td>{files.id}</td>
                            <td class="text-center">
                              {FILETYPE.map(f =>
                                f.id === files.type ? (
                                  <div>{f.fileType_name}</div>
                                ) : (
                                  <div></div>
                                )
                              )}
                            </td>

                            <td class="text-center">
                              <a
                                href={files.documentPath}
                                download={files.name}
                              >
                                {files.name}
                              </a>
                            </td>
                            <td class="text-center">
                              {FILETYPE.map(f =>
                                f.id === files.type ? (
                                  <i class={`${f.icon}`} aria-hidden="true"></i>
                                ) : (
                                  <div></div>
                                )
                              )}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="4">
                            <div class="pager">
                              {error ? (
                                <div className="text-danger">{error}</div>
                              ) : (
                                <div>
                                  <Spinner
                                    height={60}
                                    width={60}
                                    visible={true}
                                  />
                                  <br />
                                  Please wait
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
                <form action="#">
                  <div class="form-group">
                    <label for="uploadSelect">
                    {t("Download_view_files.field_13")}
                    </label>

                    <select
                      class="form-control"
                      id="uploadSelect"
                      defaultValue={fileTypeD}
                      onChange={handleDropdown}
                    >
                      {FILETYPE.map(f => (
                        <option value={f.id}>{f.fileType_name}</option>
                      ))}
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="file">
                    {t("Download_view_files.field_14")}
                    </label>
                    <input
                      type="file"
                      class="form-control-file"
                      id="file"
                      onChange={e => onChange(e)}
                    />
                    <span class="text-danger ">{uploadedFile}</span>
                  </div>
                  <div class="form-group text-right ">
                    <button
                      type="button"
                      class="btn btn-success mr-2"
                      onClick={onFileUpload}
                    >
                      Upload
                    </button>
                    <button
                      type="button"
                      class="btn btn-secondary"
                      data-dismiss="modal"
                      onClick={props.onHide}
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>

      </Modal>
    </div>
  );
}
const fileModalComponent = withTranslation()(FileModalComponent);
export default fileModalComponent;
