import React, {  useState, useEffect } from "react";
import { Modal } from "react-bootstrap";
import axios from "axios";
import { ENROLOPERATORLEVEL } from "../../constants/operatorLevel";
import { handleError,handleGetlistError } from "../../constants/error";
import { toast } from "react-toastify";
import { FILETYPE } from "../../constants/fileType";
import config from "../../config/index";
import { Spinner } from "../spinner/spinner";
import { withTranslation } from "react-i18next";
const { API_BASE_URL } = config;

export const VerifyModal=(props)=> {
  const [fileList, setFileList] = useState([]);
  const [loader, setLoader] = useState(false);

const [error, setError] = useState()

  useEffect(() => {
    props.show && 
    axios({
      method: "post",
      url: API_BASE_URL + "files/getList",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        email: atob(localStorage.getItem("email")),
        lastSessionId: atob(localStorage.getItem("lsi")),
         
        Pragma: 'no-cache'
      },
      data: {
        participantsId: props.participant.id
      }
    })
      .then(response => {
        console.log(response.data);
        setFileList(response.data.fileDtoList);
      })
      .catch((err) => {handleGetlistError(err,props.Props)
        setError("Fiche(s) pas retrouvé")
      
      });
      return()=>{console.log("unmount")
      setFileList([])
      setError(null)
      setLoader(false)
    }
  },[props.show]);
console.log(props.pageCode, props.enrolStatus)


  const onHold=()=>{
    debugger
   
    setLoader(true);
    axios({
      method: "post",
      url: API_BASE_URL + "participants/update?id="+ props.participant.id+"&ordShares=0&extrShares=0&enrolStatus=4&email=",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        Pragma: 'no-cache',
        id:localStorage.getItem("staffId"),
        email: atob(localStorage.getItem("email")),
        lastSessionId: atob(localStorage.getItem("lsi"))
      },
      data: {
       
      }
    })
      .then(response => {
        console.log(response.data);
        toast.success("Emargement maintenue en attente", {
          position: toast.POSITION.TOP_RIGHT,
          toastId: 5,
          autoClose: 3000
        });
        setLoader(false);
      props.onHide()
      

      })
      .catch((err) => {handleError(err,props.Props)
        setLoader(false)
      });
  }
  const onVerify=()=>{
    debugger

    const staffId=localStorage.getItem("staffId")
    console.log(staffId)
    setLoader(true);
    axios({
      method: "post",
      url: API_BASE_URL + "verifyApi2?pageCode="+props.pageCode,
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        email: atob(localStorage.getItem("email")),
        lastSessionId: atob(localStorage.getItem("lsi")),
         
         Pragma: 'no-cache'
      },
      data: {
        id: props.participant.id,
        operatorId:parseInt(staffId),
        enrolStatus: props.enrolStatus
      }
    })
      .then(response => {
        console.log(response.data);
       
        toast.success("Emargement vérifié", {
          position: toast.POSITION.TOP_RIGHT,
          toastId: 4,
          autoClose: 3000
        });
        setLoader(false);
        console.log("inside v",props);
        props.onHide()
        
      })
      .catch((err) => {handleError(err,props.Props)
        setLoader(false)
      });
  }
  const { t } = props.Props;
  return (
    <div>
       
      <Modal centered size="md" show={props.show} onHide={props.onHide}>
      {loader ? (
              <div class="pager ">
                <div class="text-center mt-50 mb-50">
                  <Spinner height={60} width={60} visible={true} />
                  <br />
                  Please wait...
                </div>
              </div>
            ) : 
        <div class="modal-content">
          <Modal.Header closeButton>
            <h5 class="modal-title">
              <strong>{props.participant.name}{" " } {props.participant.surname}</strong>
            </h5>
          </Modal.Header>
          
          <div class="modal-body">
            <div>
              <strong class="text-secondary">{t("Green_button.field_1")}:</strong>{" "}
              {props.participant.id}
              <br />
           
             
             
              <strong class="text-secondary">{t("Green_button.field_3")}:</strong>{" "}
              {props.participant.agdUser === true ? "YES" : "NO"}
              <br />
          
              <strong class="text-secondary">{t("Green_button.field_4")}:</strong>{" "}
              {ENROLOPERATORLEVEL.map(
                l =>
                  l.id === props.participant.enrolOpratorLevel && (
                    <span>{l.level}</span>
                  )
              )}
              <br/>
               <strong class="text-secondary"> {t("Green_button.field_5")}:</strong>{" "}
              {props.participant.ordShares}
              <br />
              <strong class="text-secondary">{t("Green_button.field_6")}:</strong>{" "}
              <span id="full-address">
                {props.participant.address}
              </span>
              <br />
              <strong class="text-secondary">{t("Green_button.field_7")}:</strong>{" "}
              <span id="full-email">{props.participant.email}</span>
              <br />
              <strong class="text-secondary">{t("Green_button.field_8")}:</strong>{" "}
              <span id="full-phone">{props.participant.mobilePhone}</span>
              <br />
            </div>
            <div class="top-marg">
            <div className="table-responsive">
              <table class="table table-bordered">
                <thead>
                  <tr class="bg-secondary text-white">
                    <th>{t("Green_button.field_9")}</th>
                    <th>{t("Green_button.field_10")}</th>
                    <th>{t("Green_button.field_11")}</th>
                    <th>{t("Green_button.field_12")}</th>
                  </tr>
                </thead>
                <tbody>
                  {fileList.length ? (
                    fileList.map(files => (
                      <tr>
                        <td>{files.id}</td>
                        <td class="text-center">
                        {
                          FILETYPE.map( f =>(
                            f.id===files.type ?<div>{f.fileType_name}</div>:<div></div>
                          ))
                        }
                        </td>

                        <td>
                          <a
                            href={files.documentPath}
                            download={files.name}
                          >
                            {files.name}
                          </a>
                        </td>

                        <td class="text-center">
                        {
                          FILETYPE.map( f =>(
                            f.id===files.type ?(
                            
                            <i class={`fa ${f.icon}`} aria-hidden="true"></i>
                         ):<div></div>
                          ))
                        }
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr >
                    <td colSpan="4">
                    <div class="pager">
                      { error ? <div className="text-danger">{error}</div>
                          : <div> 
                             <Spinner height={60} width={60} visible={true}/>
                             <br/>
                             Please wait
                             </div>}
                  </div>
                    </td>
                  
                  </tr>
                  )}
                </tbody>
              </table>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            {
              props.participant.email==null || props.participant.email==""?
              <div className="text-danger ">
              {t("Green_button.field_13")}
            </div>:<></>
            }
            
            <button type="button" class="btn btn-success" onClick={onVerify} disabled={props.participant.email==null || props.participant.email==""}>
            Validate
            </button>
            <button type="button" class="btn btn-danger" hidden={props.hidden} onClick={onHold} disabled={props.participant.email==null ||props.participant.email==""}>
                Hold
              </button>
            <button
              type="button"
              class="btn btn-secondary"
              data-dismiss="modal"
              onClick={props.onHide}
            >
              Cancel
            </button>
            
          </div>
          
        </div>
      }   
      </Modal>
        
    </div>
  );
}
const verifyModal = withTranslation()(VerifyModal);


export default verifyModal;
