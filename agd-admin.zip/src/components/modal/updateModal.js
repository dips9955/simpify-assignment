import React, {  useState, useEffect } from "react";
import { Modal } from "react-bootstrap";
import axios from "axios";
import config from "../../config/index";
import Input from "../inputField/inputField";
import { handleError } from "../../constants/error";
import {  toast } from 'react-toastify';
import { ENROLOPERATORLEVEL } from "../../constants/operatorLevel";
import { withTranslation } from "react-i18next";
import { Spinner } from "../spinner/spinner";

const { API_BASE_URL } = config;
export  function UpdateModal(props) {
const [shares, setShares] = useState(null)
const [sharesUser, setSharesUser] = useState()
const [sharesError, setSharesError] = useState()
const [email, setEmail] = useState(null)
const [emailUser, setEmailUser] = useState()
const [emailError, setEmailError] = useState()
const [loader, setLoader] = useState(false);

useEffect(() => {
  console.log("email",props.participant.email)
  setSharesUser(props.participant.ordShares!=null?props.participant.ordShares:"")
  setEmailUser(props.participant.email!=null?props.participant.email:"")

  return () => {
    console.log("unmount");
    setShares()
    setSharesError()
    setEmail()
    setSharesUser("")
    setEmailUser("")

      setEmailError()
      setLoader(false)
  };
}, [props.show]);
  const handleCallback = (name, value, childData) => {
    console.log(childData);

    if (name === "shares") {
      setShares(value)
      setSharesUser(value)
      setSharesError(childData)
    }else if (name === "email") {
      setEmail(value)
      setEmailUser(value)
      setEmailError(childData)
    } 
  };
  const onUpdate=()=>{
    debugger
    setLoader(true);
    const s =shares||""
    const e =email||""
    axios({
      method: "post",
      url: API_BASE_URL + "participants/update?id="+ props.participant.id+"&ordShares="+s+"&extrShares="+s+"&enrolStatus=0&email="+e,
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        id:localStorage.getItem("staffId"),
        email: atob(localStorage.getItem("email")),
        lastSessionId: atob(localStorage.getItem("lsi")),
        Pragma: 'no-cache'
       
      },
      data: {
       
      }
    })
      .then(response => {
        console.log(response.data);
        toast.success("Fiche bien actualisée", {
          position: toast.POSITION.TOP_RIGHT,
          toastId:6,
          autoClose: 3000
        });
        setLoader(false);

        props.onHide()

      })
      .catch((err) => {handleError(err,props.Props)
      
      setLoader(false)});
  }
  const { t } = props.Props;
  return (
    <div>
      <Modal centered size="md" show={props.show} onHide={props.onHide}>
      {loader ? (
              <div class="pager ">
                <div class="text-center mt-50 mb-50">
                  <Spinner height={60} width={60} visible={true} />
                  <br />
                  Please wait...
                </div>
              </div>
            ) : 
        <div class="modal-content">
        <Modal.Header closeButton >
            <h5 class="modal-title">
              <strong>Update</strong>
            </h5>
           
          </Modal.Header>
          <div class="modal-body">
            <div>
              <strong class="text-secondary">{t("update.field_1")} :</strong>{" "}
              <strong>{props.participant.name}{" " } {props.participant.surname}</strong>
              <br />
              <strong class="text-secondary">{t("update.field_2")}:</strong>{" "}
              <span id="full-id">{props.participant.id}</span>
              <br />
              <strong class="text-secondary">{t("update.field_3")}:</strong>{" "}
              {props.participant.agdUser === true ? "YES" : "NO"}
              <br />
            
              <strong class="text-secondary">{t("update.field_4")}:</strong>{" "}
              {ENROLOPERATORLEVEL.map(
                l =>
                  l.id === props.participant.enrolOpratorLevel && (
                    <span>{l.level}</span>
                  )
              )}
              <br/>
              <strong class="text-secondary"> {t("update.field_5")}:</strong>{" "}
              {props.participant.ordShares}
              <br />
              <strong class="text-secondary">{t("update.field_6")}:</strong>{" "}
              <span id="full-address">
                {props.participant.address}
              </span>
              <br />
              <strong class="text-secondary">{t("update.field_7")}:</strong>{" "}
              <span id="full-email">{props.participant.email}</span>
              <br />
              <strong class="text-secondary">{t("update.field_8")}:</strong>{" "}
              <span id="full-phone">{props.participant.mobilePhone}</span>
              <br />
            </div>
            <div class="top-marg">
              <form action="#">
                <div class="form-group row">
                <div class="col-sm-4 col-form-label">{t("update.field_7")}</div>
                  <div class="col-sm-6 mb-3">
                    <Input
                      type="email"
                      class="form-control"
                      id="email"
                      name="email"
                      value={emailUser}
                      placeholder="Entrez un E-mail"
                      parentCallback={handleCallback}
                    />
                     <div class="text-danger">{emailError}</div>
                  </div>
                  <div class="col-sm-4 col-form-label">{t("update.field_9")}</div>
                  <div class="col-sm-6">
                    <Input
                      type="number"
                      class="form-control"
                      id="shares"
                      name="shares"
                      min="1"
                      placeholder="Entrez le nombre d'actions"
                      value={sharesUser}
                      parentCallback={handleCallback}
                    />
                     <div class="text-danger">{sharesError}</div>
                  </div>
                 
                </div>
               
                <br />
                <div class="form-group text-center ">
                  <button type="button" class="btn btn-success mr-2" disabled={sharesError  || emailError || (!email && !shares) } onClick={onUpdate}>
                    Update
                  </button>
                  <button
                    type="button"
                    class="btn btn-secondary"
                    data-dismiss="modal"
                    onClick={ props.onHide}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      }
      </Modal>
    </div>
  );
}
const updateModal = withTranslation()(UpdateModal);

export default updateModal