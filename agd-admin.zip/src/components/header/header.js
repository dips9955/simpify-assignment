import React, { Component } from "react";
import { Navbar, Nav, Form } from "react-bootstrap";
import axios from "axios";
import config from "../../config/index";
import {Link} from 'react-router-dom'
import { withTranslation } from "react-i18next";

import { ToastContainer, toast } from 'react-toastify';
import { handleError } from "../../constants/error";
import TranslationDropdown from "../translationDropdown";
import { Create } from "../../screens/create-participant";
const  {API_BASE_URL} = config;

export class Header extends Component {
  constructor(props) {
    super(props);
  }
  logout = () => {
    axios({
      method: "post",
      url: API_BASE_URL + "user/logout",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Pragma: 'no-cache'
      },
      data: {
        meetingId:atob(localStorage.getItem('meetingId')),
        email: atob(localStorage.getItem('email')),
      },
    })
      .then((response) => {
        console.log(response.data);
        localStorage.clear()
        
        this.props.history.push("/");
        toast.success("Déconnexion réussie", {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 3000
        });
      })
      .catch((err) =>{
        handleError(err)})
  
  };
  
  

  render() {
    const {t} = this.props
    console.log("dd",this.props)
    return (
      <div>
        <Navbar bg="dark" variant="dark">
          <Navbar.Brand href="#">AGD - {atob(localStorage.getItem("meetingName"))}</Navbar.Brand>
          <TranslationDropdown {...this.props}/>
          <Nav className="mr-auto"></Nav>
          <Form inline>
       
          <div></div>
          <Link  style={{ color:"yellow",marginRight:"2px"}}
         // {...this.props}
           to={{
            pathname: "/create",
            state: {
            ["activeKey"]:this.props.activeKey,
          }, 
          Props:this.props
          }}
        onClick={
          localStorage.setItem("props",this.props)
        }
           >{t("common.title_1")}</Link> 

          <Nav.Link  style={{ color:"yellow",marginRight:"2px"}} href="#"onClick={this.logout} ><i class="fa fa-power-off" aria-hidden="true" ></i> {t("common.title_2")}</Nav.Link>
          <div  style={{ color:"white",marginRight:"2px"}}>Welcome {(atob(localStorage.getItem("staffUserName")))}</div>

          </Form>
        </Navbar>
        <ToastContainer />
     

      </div>
    );
  }
}
const header = withTranslation()(Header)
export default header;
