import React from 'react'
import i18n from "i18next";



const languages = [
  { language: "Français", value: "fr" },

  { language: "English", value: "en" }

   
  ];
  const options = ["en-US", "en-GB", "en-AU", "en-BZ", "en-CA", 
                  "en-IE", "en-JM", "en-NZ", "en-ZA", "en-TT", "en"];
  var lang;
export default function TranslationDropdown(props) {

    let language = localStorage.getItem('i18nextLng')? localStorage.getItem('i18nextLng') :languages[0].value
    console.log("language",language)
for (var i=0; i<languages.length; i++){
      if (languages[i].value === language) {

        lang=languages[i].language       
      }   
      
      else if(options.includes(language)) {
        lang="English"
      }
      
      else if(language === "fr-GB" || "fr-be" || "fr-ca" ||"fr-lu" ||"fr" || "fr-ch" || "fr") {
        lang="Français"
      }  
      else{
        lang="English"
      }                
    }
  const [valueL, setValueL] =  React.useState(lang)
  
  const [inputValue, setInputValue] = React.useState();

  const handleOnChange=(e)=>{
    setValueL(e.target.value)
    if(e.target.value ==="fr"){
        i18n.changeLanguage("fr");
      }
      else if(e.target.value ==="en"){
        i18n.changeLanguage("en");
      }
  }
  
    return (
        <div>
            <select 
                defaultValue={lang}
                class="form-control" 
                onChange={(e)=>handleOnChange(e)} 
                >
                    {
                         languages.map((l) => (
                         <option value={l.value}>{l.language}</option>
                         ))
                    }
             

            </select>
        </div>
    )
}
