import React, { Component } from 'react'

export class Dropdown extends Component {
  constructor(props){
    super(props)
  }
    render() {
        return (
            <div>
          {this.props.l3}:<br/>
            <select 
                value={this.props.selectValue}
                class="form-control" 
                onChange={this.props.handleOnChange} 
                style={{
                  backgroundColor: this.props.selectValue !=0
                    ? "lightYellow"
                    : "transparent"
                }}
                >
              <option value={0}>{this.props.all}</option>
              <option value={1}>{this.props.l1}</option>
              <option value={2}>{this.props.l2}</option>
            </select>
      </div>
        )
    }
}

export default Dropdown
