import Loader from "react-loader-spinner";
import React from "react";

export  const Spinner=(props)=>  {
  
    return (
      <Loader
        type="TailSpin"
        color="#6c757d"
        height={props.height}
        width={props.width}
        visible={props.visible}
        timeout={props.timeout}
      />
    );
  
}