import React from "react";
import {
  EMAIL_REGEX,
  PASSWORD_REGEX,
  
  NUMBER_REGEX
} from "../../constants/constants";

export default class Input extends React.Component {
  constructor(props) {
    super();
  }

  parentCallback = e => {
   debugger
    let error=""

    const { name, value } = e.target;
    console.log(name, value);

    switch (name) {
      case "id":
         
        this.props.parentCallback(name, value);
        break;
      case "fName":
          if (!value) {
            error = "obligatoire";
          } else if (value.length > 50) {
            error ="doit contenir 50 caractères ou moins";
          } else if (!/^([a-zA-Z0-9 ]+)$/i.test(value)) {
            error = "Prénom invalide";
          }
        this.props.parentCallback(name, value,error);
        break;
      case "lName":
          if (!value) {
            error = "obligatoire";
          } else if (!/^([a-zA-Z0-9 ]+)$/i.test(value)) {
            error = "nom de famille invalide";
          }
          else if (value.length > 50) {
            error ="doit contenir 50 caractères ou moins";
          } 
        this.props.parentCallback(name, value,error);
        break;
      case "operatedId":
        this.props.parentCallback(name, value);
        break;
      case "email":
         
           if (value.length < 1) {
          }
          else if (
            !/^\w[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value)
          ) {
            error = "e-mail incomplet";
          }
           else if (value.length > 65) {
            error = "doit contenir 65 caractères ou moins"
          }

        this.props.parentCallback(
          name,
          value,
         error
        );
        break;
      case "confirmEmail":
        this.props.parentCallback(
          name,
          value,
          EMAIL_REGEX.test(value) ? "" : "e-mail incomplet"
        );
        break;
      case "loginPassword":
        this.props.parentCallback(
          name,
          value,
          value.length < 1 ? " saisissez votre mot de passe" : ""
        );
        break;
      case "password":
        this.props.parentCallback(
          name,
          value,
          PASSWORD_REGEX.test(value) ? "" : "password doesn't match criteria"
        );
        break;
      case "confirmPassword":
        this.props.parentCallback(
          name,
          value,
          value.length < 8 ? "confirm password doesnt match" : ""
        );
        break;
      case "search":
        this.props.parentCallback(name, value);
        break;

      
      case "lastVotaAccessDigit":
        this.props.parentCallback(
          name,
          value
        );
        break;
      case "address":
          if (!value) {
            error = "obligatoire";
          }else if (!/^([a-zA-Z0-9 ]+)$/i.test(value)) {
            error = "Adresse invalide";
          }
           else if (value.length > 100) {
            error ="doit contenir 100 caractères ou moins";
          } 
        this.props.parentCallback(name, value,error);
        break;
      case "zipcode":
          if (value) {
          if (!/^[a-zA-Z0-9{10}\s]+$/i.test(value)) {
            error = "code postal invalide";
          } 
           else if (value.length > 12) {
            error = "doit contenir 12 caractères ou moins";
          }
        }
        this.props.parentCallback(
          name,
          value,
          error
        );
        break;
      case "city":
          if (!value) {
            error = "obligatoire";
          } else if (!/^[a-zA-Z0-9\s]+(?:(?:\\s+|-)[a-zA-Z/]+)*$/i.test(value)) {
            error = "ville invalide ";
          } else if (value.length > 35) {
            error = "doit contenir 35 caractères ou moins";
          }
        this.props.parentCallback(
          name,
          value,
          error
        );
        break;
        case "mobileNo":
            if (
           ! NUMBER_REGEX.test(value)
  
            ) {
              error = "Téléphone portable invalide";
            } else if (value.length > 12) {
              error = "doit contenir 12 caractères ou moins"
            }
        this.props.parentCallback(
          name,
          value,
          error
        );
        break;
        case "countryCode":
            if (
           ! NUMBER_REGEX.test(value)
  
            ) {
              error = "Code de pays invalide";
            } else if (value.length > 3) {
              error = "doit contenir 3 caractères ou moins"
            }
        this.props.parentCallback(
          name,
          value,
          error
        );
        break;
        case "shares":
        case "ord_shares":
        case "ord_votes":
        case "extr_share":
        case "extr_votes":

            debugger
            if ( ! NUMBER_REGEX.test(value)) {
              error = "saisissez un nombre d’actions valide";
            }else if(value == ""){
              //error=""
            }
            else if(value==0 ){
              error = "saisissez un nombre d’actions valide";

            } else if (value.length > 65) {
              error = "doit contenir 65 caractères ou moins"
            }
          this.props.parentCallback(
            name,
            value,
            error
          );
          break;
       
      default:
        break;
    }
   
  };

  render() {

    return (
      <div>
        <input
          id={this.props.id}
          style={this.props.style}
          key={this.props.name}
          placeholder={this.props.placeholder}
          type={this.props.type}
          onChange={this.parentCallback}
          name={this.props.name}
          maxLength={this.props.maxLength}
          class={this.props.class}
          min={this.props.min}
          pattern={this.props.pattern}
          onKeyPress={this.props.onKeyPress}
          value={this.props.value}
        />
      </div>
    );
  }
}
