import React, { Component } from 'react'

  export default class Sorting extends Component {
      constructor(props){
        super(props)
      }
      componentDidMount(){
        // console.log("sortProps",this.props)
      }
      

  
    render() {
      return(
        <div class="spinners">
        <i
          class="fa fa-caret-up "
          id="asc"
          aria-hidden="true"
          onClick={()=>this.props.handleGetlistSortByDesc()}
        ></i>
        <i
          class="fa fa-caret-down"
          id="desc"
          aria-hidden="true"
          onClick={()=>this.props.handleGetlistSortByAsc()}
        ></i>
      </div>
    )
    }
  }


