import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import "font-awesome/css/font-awesome.min.css";
import 'react-toastify/dist/ReactToastify.css';
import history from "../src/services/history"

import RootNavigation from "./routes";

function App() {
  return (
    <RootNavigation history={history}/>
  );
}

export default App;
