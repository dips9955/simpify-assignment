import React from "react";
import { Switch, Route,BrowserRouter } from "react-router-dom";
import Login from "../screens/login/index";
import TabComponent from "../screens/tabs/index"
import { Create } from "../screens/create-participant";
import setPin from "../screens/set-pin";
import ForgotPassword from "../screens/forget-password";
import ResetPassword from "../screens/reset-password";
import  View  from "../screens/view-participant";
import history from "../services/history"
const rootNavigation = () => {
  return (
    <div>
      <BrowserRouter history={history}>
        <Switch>
          <Route exact path="/" component={Login} /> 
          <Route exact path="/admin" component={TabComponent} /> 
          <Route exact path="/create" component={Create} /> 
          <Route exact path="/pin" component={setPin} /> 
          <Route exact path="/forgot" component={ForgotPassword} /> 
          <Route exact path="/reset" component={ResetPassword} /> 
          <Route exact path="/view" component={View} /> 

        
          

          
          


        </Switch>
      </BrowserRouter>
    </div>
  );
};

export default rootNavigation;