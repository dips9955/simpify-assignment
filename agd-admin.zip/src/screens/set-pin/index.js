import React, { Component } from "react";

export class SetPin extends Component {
  render() {
    return (
      <div>
        <div class="login-panel">
          <h2 class="text-center text-uppercase">OTP to Reset Password</h2>
          <form action="reset-password.html">
            <div class="text-center">
              Enter the OTP from email to go to Reset Password
            </div>
            <br />
            <div class="form-group">
              <input
                type="text"
                class="form-control"
                id="otp"
                placeholder="Enter OTP"
              />
              <small class="form-text text-danger"></small>
            </div>
            <div class="form-group text-right">
              <button type="submit" class="btn btn-primary">
                Verify OTP
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default SetPin;
