import React, { Component } from "react";
import Input from "../../components/inputField/inputField";
import config from "../../config/index";
import axios from "axios";
import {  Redirect } from "react-router-dom";
import {Dropdown,DropdownButton} from "react-bootstrap"
import { ToastContainer } from "react-toastify";
import "bootstrap/dist/css/bootstrap.min.css";
import { handleError } from "../../constants/error";
const { API_BASE_URL } = config;

class Login extends Component {
  constructor(props) {
    super(props);
    const token = localStorage.getItem("token");
    let loggedIn = true;
    if (token == null) {
      loggedIn = false;
    }
    this.state = {
      loggedIn,
      email: null,
      password: null,
      selectMeetingId: null,
      selectMeetingName: null,
      selectMeetingDate: null,
      meetingNameList: [],
      formErrorsEmail: null,
      formErrorsPassword: null,
      formErrorsVotaaccess: null
    };
  }

  componentDidMount() {
    axios({
      method: "get",
      url: API_BASE_URL + "meetings/",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        Pragma: "no-cache"
      }
    })
      .then(response => {
        console.log(response.data.meetingDtoList);
        this.setState({ meetingNameList: response.data.meetingDtoList });
      })
      .catch(err => handleError(err));
  }
  handleCallback = (name, value, childData) => {
    console.log(childData);

    if (name === "email") {
      this.setState({ formErrorsEmail: childData });
      this.setState({ email: value });
    } else if (name === "loginPassword") {
      this.setState({ formErrorsPassword: childData });
      this.setState({ password: value });
    }
  };

  login = (e) => {
    e.preventDefault()
    const {
      email,
      password,
      selectMeetingId,
      selectMeetingName,
      selectMeetingDate
    } = this.state;

    console.log("click", selectMeetingId, selectMeetingName, selectMeetingDate);
    if (email && password) {
      axios({
        method: "post",
        url: API_BASE_URL + "user/login",
        headers: {
          "content-type": "application/json",
          accept: "application/json",
          Pragma: "no-cache"
        },
        data: {
          meetingId: this.state.selectMeetingId,
          email: email,
          password: password
        }
      })
        .then(response => {
          console.log("id", response.data.staffUserDto.id);
          localStorage.setItem("email", btoa(response.data.staffUserDto.email));
          localStorage.setItem("staffUserName", btoa(response.data.staffUserDto.name));
          localStorage.setItem("staffUserSurname", btoa(response.data.staffUserDto.surname));
          localStorage.setItem(
            "lsi",
            btoa(response.data.staffUserDto.lastSessionId)
          );
          localStorage.setItem("token", btoa(response.data.staffUserDto.login));
          localStorage.setItem("staffId", response.data.staffUserDto.id);

          localStorage.setItem("meetingId", btoa(this.state.selectMeetingId));
          localStorage.setItem(
            "meetingName",
            btoa(this.state.selectMeetingName)
          );
          localStorage.setItem(
            "meetingDate",
            btoa(this.state.selectMeetingDate)
          );

        
          this.props.history.push("/admin");
        })
        .catch(err => handleError(err));
    } else {
      if (email === null && password === null) {
        this.setState({
          formErrorsEmail: " saisissez votre e-mai ",
          formErrorsPassword: " saisissez votre mot de passe"
        });
      } else if (email === null) {
        this.setState({ formErrorsEmail: "saisissez votre e-mai" });
      } else if (password === null) {
        this.setState({ formErrorsPassword: "saisissez votre mot de passe" });
      }
    }
  };

  handleOnChange(e) {
    console.log("n", JSON.parse(e).id);
    console.log("n", JSON.parse(e).name);
    console.log("n", JSON.parse(e).date);
    this.setState({
      selectMeetingId: JSON.parse(e).id
    });
    this.setState({
      selectMeetingName: JSON.parse(e).name
    });
    this.setState({
      selectMeetingDate: JSON.parse(e).date
    });

   
  }
  render() {
    if (this.state.loggedIn === true) {
      return <Redirect to="/admin" />;
    }
    return (
      <div>
        <ToastContainer />
        <div class="login-panel">
          <h2 class="text-center text-uppercase">Sign In</h2>
          <form onSubmit={(e)=>this.login(e)}>
            <div class="form-group">
              <Input
                type="email"
                name="email"
                class="form-control"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                placeholder="saisissez votre e-mail"
                parentCallback={this.handleCallback}
              />
              <small class="form-text text-danger">
                {this.state.formErrorsEmail}
              </small>
            </div>
            <div class="form-group">
              <Input
                type="password"
                name="loginPassword"
                class="form-control"
                id="exampleInputPassword1"
                placeholder="saisissez votre mot de passe"
                parentCallback={this.handleCallback}
              />
              <small class="form-text text-danger">
                {this.state.formErrorsPassword}
              </small>
            </div>
            <div className="mb-4">
            <DropdownButton   
                
                variant="info"
             onSelect={this.handleOnChange.bind(this)}
              title={this.state.selectMeetingName?this.state.selectMeetingName:"select Meeting"}
              >
            {this.state.meetingNameList.map(m => (
              <Dropdown.Item 
                 eventKey={JSON.stringify({
                  id: m.id,
                  name: m.name,
                  date: m.date
                })}
              > {m.name}</Dropdown.Item>
            ))}
            </DropdownButton>

            </div>
            <div class="row">
              <div class="col-6 ">{/* <a href="#">Forgot Password</a> */}</div>
              <div class="col-6 text-right">
                
                <button
                  type="submit"
                  class="btn btn-primary"

                  disabled={
                    this.state.formErrorsEmail ||
                    this.state.formErrorsPassword ||
                    !this.state.email ||
                    !this.state.password ||
                    !this.state.selectMeetingName
                  }
                  onClick={(e) => this.login(e)}
                >
                  Sign In
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default Login;
