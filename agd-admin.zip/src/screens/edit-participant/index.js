import React, { Component } from "react";
import Header from "../../components/header/header";

export class Edit extends Component {
  render() {
    return (
      <div>
        <Header />

        <div class="agd-container">
          <div class="row">
            <div class="col-md-1 col-lg-2 col-xl-3"></div>
            <div class="col-md-10 col-lg-8 col-xl-6">
              <div
                class="alert alert-success alert-dismissible fade show"
                role="alert"
              >
                Details saved successfully.
                <button
                  type="button"
                  class="close"
                  data-dismiss="alert"
                  aria-label="Close"
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <h2>Edit Participant</h2>
              <strong>Participant ID:</strong> 94375 |{" "}
              <strong>Meeting ID:</strong> 8745 | <strong>AGD ID:</strong> 6543{" "}
              <br />
              <span class="text-secondary">
                (Above info is sample info - display whatever needs to be shown)
              </span>
              <br />
              <br />
              <div class="card">
                <div class="card-body">
                  <form>
                    <div class="form-group row">
                      <label for="firstname" class="col-sm-2 col-form-label">
                        First Name
                      </label>
                      <div class="col-sm-10">
                        <input
                          type="text"
                          class="form-control"
                          readonly
                          id="firstname"
                          name="firstname"
                          placeholder="Enter First Name"
                        />
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="lastname" class="col-sm-2 col-form-label">
                        Last Name
                      </label>
                      <div class="col-sm-10">
                        <input
                          type="text"
                          class="form-control"
                          readonly
                          id="lastname"
                          name="lastname"
                          placeholder="Enter Last Name"
                        />
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="title" class="col-sm-2 col-form-label">
                        Title
                      </label>
                      <div class="col-sm-10">
                        <select
                          name="title"
                          id="title"
                          class="form-control"
                          readonly
                        >
                          <option>Select Title</option>
                          <option>Society</option>
                          <option>Corresponding</option>
                          <option>...Values from JSON...</option>
                        </select>
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="address" class="col-sm-2 col-form-label">
                        Address
                      </label>
                      <div class="col-sm-10">
                        <input
                          type="text"
                          class="form-control"
                          id="address"
                          name="address"
                          readonly
                          placeholder="Enter Address"
                        />
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="zip" class="col-sm-2 col-form-label">
                        Zipcode
                      </label>
                      <div class="col-sm-10">
                        <input
                          type="text"
                          class="form-control"
                          id="zip"
                          name="zip"
                          readonly
                          placeholder="Enter Zipcode"
                        />
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="city" class="col-sm-2 col-form-label">
                        City
                      </label>
                      <div class="col-sm-10">
                        <input
                          type="text"
                          class="form-control"
                          id="city"
                          name="city"
                          readonly
                          placeholder="Enter City"
                        />
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="country" class="col-sm-2 col-form-label">
                        Country
                      </label>
                      <div class="col-sm-10">
                        <select
                          name="country"
                          id="country"
                          class="form-control"
                          readonly
                        >
                          <option>Select Country</option>
                          <option>Switzerland</option>
                          <option>France</option>
                          <option>Italy</option>
                          <option>Germany</option>
                        </select>
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="country" class="col-sm-2 col-form-label">
                        Country
                      </label>
                      <div class="col-sm-10">
                        <select
                          name="language"
                          id="language"
                          class="form-control"
                          readonly
                        >
                          <option>Select Language</option>
                          <option value="EN">English</option>
                          <option value="FR">French</option>
                          <option value="IT">Italian </option>
                          <option value="DE">German</option>
                        </select>
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="email" class="col-sm-2 col-form-label">
                        Email
                      </label>
                      <div class="col-sm-10">
                        <input
                          type="text"
                          class="form-control"
                          id="email"
                          name="email"
                          placeholder="Enter Email"
                          readonly
                        />
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="mobile" class="col-sm-2 col-form-label">
                        Mobile phone
                      </label>
                      <div class="col-sm-10">
                        <input
                          type="text"
                          class="form-control"
                          id="mobile"
                          name="mobile"
                          placeholder="Enter Mobile Phone Number"
                          readonly
                        />
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="type" class="col-sm-2 col-form-label">
                        Participant Type
                      </label>
                      <div class="col-sm-10">
                        <input
                          type="text"
                          class="form-control-plaintext"
                          readonly
                          id="type"
                          name="type"
                          value="11 - Unexpected bearer shareholder"
                          readonly
                        />
                        <span class="text-danger hide">Error</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="type" class="col-sm-2 col-form-label"></label>
                      <div class="col-sm-10">
                        <button type="submit" class="btn btn-success btn-lg">
                          Submit
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Edit;
