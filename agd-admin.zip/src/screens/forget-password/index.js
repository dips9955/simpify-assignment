import React, { Component } from "react";

export class ForgotPassword extends Component {
  render() {
    return (
      <div>
        <div class="login-panel">
          <h2 class="text-center text-uppercase">Forgot Password?</h2>
          <form action="enter-pin.html">
            <div class="text-center">
              We will send you an email with OTP to reset password.
            </div>
            <br />
            <div class="form-group">
              <input
                type="email"
                class="form-control"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                placeholder="Enter Email"
              />
              <small class="form-text text-danger"></small>
            </div>
            <div class="form-group text-right">
              <button type="submit" class="btn btn-primary" onClick={()=> this.props.history.push()}>
                Send OTP on Email
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default ForgotPassword;
