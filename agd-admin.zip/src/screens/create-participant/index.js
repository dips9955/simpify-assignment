import React, { Component } from "react";
import { Link, Redirect } from "react-router-dom";
import { TITLE } from "../../constants/title";
import { BADGE } from "../../constants/bagde";
import Input from "../../components/inputField/inputField";
import { handleError } from "../../constants/error";
import { Dropdown, DropdownButton,Navbar, Nav, Form } from "react-bootstrap";
import { withTranslation } from "react-i18next";
import axios from "axios";
import config from "../../config/index";
import { toast, ToastContainer } from "react-toastify";
import { Spinner } from "../../components/spinner/spinner";
const { API_BASE_URL } = config;

export class Create extends Component {
  constructor(props) {
    super(props);
    const token = localStorage.getItem("token");
    let loggedIn = true;
    if (token == null) {
      loggedIn = false;
    }
    this.state = {
      loggedIn, fName: "", lName: "",titleId: "",titleName:"",
      address: "",
      zipcode: "",
      city: "",
      email: null,
      mobileNo: "",
      typeId: "",
      typeName: "",
      ord_shares: "",
      ord_votes:"",
      extr_share:"",
      extr_votes:"",
      formErrorfName: "",
      formErrorlName: "",
      formErrortitle: "",
      formErroraddress: "",
      formErrorzipcode: "",
      formErrorcity: "",
      formErroremail: "",
      formErrormobileNo: "",
      formErrortype: "",
      formErrorord_shares: "",
      formErrorord_votes: "",
      formErrorextr_share: "",
      formErrorextr_votes: "",
      loader:false,
      formErrorCountryCode:"",
      countryCode:""
    };
  }

  handleCallback = (name, value, childData) => {
    const {countryCode,mobileNo
      , formErrorCountryCode,formErrormobileNo}=this.state
    if (name === "fName") {
      this.setState({ formErrorfName: childData });
      this.setState({ fName: value });
    } else if (name === "lName") {
      this.setState({ formErrorlName: childData });
      this.setState({ lName: value });
    } else if (name === "email") {
      this.setState({ formErroremail: childData });
      if(value.trim()==""){
      this.setState({ email: null });

      }else{
      this.setState({ email: value });
      }
    } else if (name === "address") {
      this.setState({ formErroraddress: childData });
      this.setState({ address: value });
    } else if (name === "zipcode") {
      this.setState({ formErrorzipcode: childData });
      this.setState({ zipcode: value });
    } else if (name === "city") {
      this.setState({ formErrorcity: childData });
      this.setState({ city: value });
    } else if (name === "mobileNo") {
      this.setState({ formErrormobileNo: childData });
      this.setState({ mobileNo: value });
    } else if (name === "ord_shares") {
      this.setState({ formErrorord_shares: childData });
      this.setState({ ord_shares: value });
    }else if (name === "ord_votes") {
      this.setState({ formErrorord_votes: childData });
      this.setState({ ord_votes: value });
    }else if (name === "extr_share") {
      this.setState({ formErrorextr_share: childData });
      this.setState({ extr_share: value });
    }else if (name === "extr_votes") {
      this.setState({ formErrorextr_votes: childData });
      this.setState({ extr_votes: value });
    }
    else if(name==="countryCode"){
      this.setState({ formErrorCountryCode: childData });
      this.setState({ countryCode: value });
    }

//     if(countryCode && mobileNo){

//     }else if(countryCode){
//   this.setState({formErrormobileNo:"please enter mobile no"})
// }else if(mobileNo){
//  this.setState({formErrorCountryCode:"please enter country code"})
// }
  };
  onFormSubmit = async() => {
    const {
      fName,lName,email,address,city,titleId,typeId,zipcode,mobileNo,ord_shares,ord_votes,extr_share,extr_votes,countryCode
     , formErrorCountryCode,formErrormobileNo} = this.state;
    this.setState({loader:true})
    
//     let mobile_number=""   
// if(countryCode&&mobileNo){
//  mobile_number = `+${countryCode}${mobileNo}`
// }else{
//  mobile_number = ""

// }
// }else if(countryCode){
//  await this.setState({formErrormobileNo:"please enter mobile no"})
// }else if(mobileNo){
// await this.setState({formErrorCountryCode:"please enter country code"})
// }
// if(!formErrorCountryCode || !formErrormobileNo){
  
    axios({
      method: "post",
      url: API_BASE_URL+"participant",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        email: atob(localStorage.getItem("email")),
        lastSessionId: atob(localStorage.getItem("lsi")),

        Pragma: "no-cache"
      },
      data: {
        meetingId:parseInt(atob(localStorage.getItem("meetingId"))),
        name:fName.toUpperCase(),
        surname:lName.toUpperCase(),
        title:titleId,
        address:address.toUpperCase(),
        zipcode:zipcode.toUpperCase(),
        city:city.toUpperCase(),
        email:email,
        mobilePhone:mobileNo?`+${mobileNo}`:"",
        type:typeId,
        ordShares:ord_shares,
        extrShares:extr_share,
        ordVotes:ord_votes,
        extrVotes:extr_votes

      }
    })
      .then(response => {
        console.log(response.data);
        toast.success("participant créé avec succès", {
          position: toast.POSITION.TOP_RIGHT,
          toastId: 20,
          autoClose: 3000
        });
        this.setState({fName:"",lName:"",email:null,address:"",city:"",titleName:"",typeName:"",zipcode:"",mobileNo:"",
        ord_shares:"",ord_votes:"",extr_share:"",extr_votes:"",loader:false,formErrorCountryCode:"",countryCode:""})
      })
      .catch(err => {handleError(err,this.props)
      this.setState({loader:false})
      });
    //}
  };
  handleOnChange(e) {
    if( JSON.parse(e).type==="title"){
    console.log("title",JSON.parse(e).id);

    this.setState({titleId: JSON.parse(e).id})
    this.setState({titleName: JSON.parse(e).name})
    }else if( JSON.parse(e).type==="type"){
    console.log("type", JSON.parse(e).id);

    this.setState({typeId: JSON.parse(e).id})
    this.setState({typeName: JSON.parse(e).name})
    }
  }
  render() {
    if (this.state.loggedIn === false) {
      return <Redirect to="/" />;
    }
    //const { t } = this.location?.state?.Props
    console.log("cc",(this.props))
    //const t =localStorage.getItem("props")
    const {
      formErrorCountryCode,
      formErrorfName,
      formErrorlName,
      formErroraddress,
      formErrorcity,
      formErroremail,
      formErrormobileNo,
      formErrorord_shares,
      formErrorord_votes,
      formErrorextr_share,
      formErrorextr_votes,
      formErrortitle,
      formErrortype,
      formErrorzipcode,
      countryCode,
      fName,lName,email,address,city,titleName,typeName,ord_shares,ord_votes,extr_share,extr_votes,zipcode,mobileNo,loader
    } = this.state;
    return (
      <div>
        <Navbar bg="dark" variant="dark">
          <Navbar.Brand href="#">AGD</Navbar.Brand>
       </Navbar>
       <ToastContainer />

        <div class="agd-container">
        {loader ? (
              <div class="pager mt-100">
                <div class="text-center  " style={{alignContent:"center"}}>
                  <Spinner height={60} width={60} visible={true} />
                  <br />
                  Please wait...
                </div>
              </div>
            ) :
          <div class="row">
            <div class="col-md-1 col-lg-2 col-xl-3"></div>
            <div class="col-md-10 col-lg-8 col-xl-6">
          
              {/* <h2>  {t("create.field_14")}</h2> */}
              <br />
              <div class=" text-right ">
              <Link
                  class="btn btn-secondary mb-2"
                  to={{
                    pathname: "/admin",
                   // state: { ["lastActiveTab"]: this.props.location.state.activeKey}
                  }}
                >
                  Back
                </Link>
              </div>
              <div class="card">
                <div class="card-body">
                
                    <div class="form-group row">
                      <label for="firstname" class="col-sm-3 col-form-label text-uppercase field-wrapper">
                        Prénom<span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-9">
                        <Input
                          type="text"
                          parentCallback={this.handleCallback}
                          class="form-control  text-uppercase"
                          id="firstname"
                          name="fName"
                          value={fName}
                          placeholder="saisissez votre Prénom"
                        />
                        <span class="text-danger hide">{formErrorfName}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="lastname" class="col-sm-3 col-form-label text-uppercase">
                        Nom<span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-9">
                        <Input
                          type="text"
                          parentCallback={this.handleCallback}
                          class="form-control text-uppercase"
                          id="lastname"
                          name="lName"
                          value={lName}
                          placeholder="saisissez votre Nom"
                        />
                        <span class="text-danger hide">{formErrorlName}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="title" class="col-sm-3 col-form-label text-uppercase">
                        Title<span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-9">
                        <DropdownButton
                          variant="secondary"
                          onSelect={this.handleOnChange.bind(this)}
                          title={
                            this.state.titleName ? this.state.titleName : "SELECT TITLE"
                          }
                        >
                          {TITLE.map(t => (
                            <Dropdown.Item eventKey={
                              JSON.stringify({
                                id: t.id,
                                type:"title",
                                name:t.title
                              })}
                            >
                              {" "}
                              {t.title}
                            </Dropdown.Item>
                          ))}
                        </DropdownButton>

                        <span class="text-danger hide">{formErrortitle}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="address" class="col-sm-3 col-form-label text-uppercase">
                        Adresse<span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-9">
                        <Input
                          type="text"
                          parentCallback={this.handleCallback}
                          class="form-control text-uppercase"
                          id="address"
                          name="address"
                          value={address}
                          placeholder="saisissez votre Address"
                        />
                        <span class="text-danger hide">{formErroraddress}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="zip" class="col-sm-3 col-form-label text-uppercase">
                      code postal
                      </label>
                      <div class="col-sm-9">
                        <Input
                          type="text"
                          parentCallback={this.handleCallback}
                          class="form-control text-uppercase"
                          id="zip"
                          name="zipcode"
                          value={zipcode}
                          placeholder="saisissez votre code postal"
                        />
                        <span class="text-danger hide">{formErrorzipcode}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="city" class="col-sm-3 col-form-label text-uppercase">
                        Ville<span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-9">
                        <Input
                          type="text"
                          parentCallback={this.handleCallback}
                          class="form-control text-uppercase"
                          id="city"
                          name="city"
                          value={city}
                          placeholder="saisissez votre Ville"
                        />
                        <span class="text-danger hide">{formErrorcity}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="email" class="col-sm-3 col-form-label ">
                        E-mail
                      </label>
                      <div class="col-sm-9">
                        <Input
                          type="email"
                          parentCallback={this.handleCallback}
                          class="form-control "
                          id="email"
                          name="email"
                          value={email}
                          placeholder="saisissez votre E-mail"
                        />
                        <span class="text-danger hide">{formErroremail}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="mobile" class="col-sm-3 col-form-label text-uppercase">
                        Mobile phone
                      </label>
                      {/* <div class="col-sm-2">
                      <Input
                          type="number"
                          parentCallback={this.handleCallback}
                          class="form-control "
                          id="mobile"
                          name="countryCode"
                          min="0"
                          value={countryCode}
                          placeholder="eg. +33"
                        />
                        <span class="text-danger hide">
                          {formErrorCountryCode}
                        </span>
                      </div> */}

                      <div class="col-sm-9">
                        <Input
                          type="number"
                          parentCallback={this.handleCallback}
                          class="form-control text-uppercase"
                          id="mobile"
                          name="mobileNo"
                          min="0"
                          value={mobileNo}
                          placeholder="saisissez votre Mobile Phone Number"
                        />
                        <span class="text-danger hide">
                          {formErrormobileNo}
                        </span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="type" class="col-sm-3 col-form-label text-uppercase">
                        Type de participationParti<span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-9">

                      <DropdownButton
                         class="col-sm-12"
                          variant="secondary"
                          onSelect={this.handleOnChange.bind(this)}
                          title={
                            this.state.typeName ? this.state.typeName : "SELECT TYPE"
                          }
                        >
                          {BADGE.map(b => (
                            <Dropdown.Item eventKey={
                              JSON.stringify({
                             id: b.id,
                             type:"type",
                            name:b.badge_frenchName
                            })}
                             >
                              {" "}
                              {b.badge_frenchName}
                            </Dropdown.Item>
                          ))}
                        </DropdownButton>

                      
                        <span class="text-danger hide">{formErrortype}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="type" class="col-sm-3 col-form-label text-uppercase">
                        Nombre d'actions ordinaires
                      </label>
                      <div class="col-sm-9">
                        <Input
                          type="number"
                          parentCallback={this.handleCallback}
                          class="form-control text-uppercase"
                          id="type"
                          name="ord_shares"
                          min="0"
                          value={ord_shares}
                          placeholder="saisissez votre Nombre d'actions ordinaires"
                        />
                        <span class="text-danger hide">{formErrorord_shares}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="type" class="col-sm-3 col-form-label text-uppercase">
                      NOMBRE DE VOIX ORDINAIRES
                      </label>
                      <div class="col-sm-9">
                        <Input
                          type="number"
                          parentCallback={this.handleCallback}
                          class="form-control text-uppercase"
                          id="type"
                          name="ord_votes"
                          min="0"
                          value={ord_votes}
                          placeholder="saisissez votre  NOMBRE DE VOIX ORDINAIRES"
                        />
                        <span class="text-danger hide">{formErrorord_votes}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="type" class="col-sm-3 col-form-label text-uppercase">
                      NOMBRE D'ACTIONS EXTRAORDINAIRES
                      </label>
                      <div class="col-sm-9">
                        <Input
                          type="number"
                          parentCallback={this.handleCallback}
                          class="form-control text-uppercase"
                          id="type"
                          name="extr_share"
                          min="0"
                          value={extr_share}
                          placeholder="saisissez votre NOMBRE D'ACTIONS EXTRAORDINAIRES"
                        />
                        <span class="text-danger hide">{formErrorextr_share}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="type" class="col-sm-3 col-form-label text-uppercase">
                      NOMBRE DE VOIX EXTRAORDINAIRES
                      </label>
                      <div class="col-sm-9">
                        <Input
                          type="number"
                          parentCallback={this.handleCallback}
                          class="form-control text-uppercase"
                          id="type"
                          name="extr_votes"
                          min="0"
                          value={extr_votes}
                          placeholder="saisissez votre  NOMBRE DE VOIX EXTRAORDINAIRES"
                        />
                        <span class="text-danger hide">{formErrorextr_votes}</span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="type" class="col-sm-3 col-form-label text-uppercase"></label>
                      <div class="col-sm-9 text-right">
                        <button
                          type="submit"
                          class="btn btn-success btn-lg"
                          disabled={formErrorfName || formErrorlName || formErroremail || formErroraddress || formErrorcity
                             || !fName || !lName  || !address || !city || !titleName || !typeName 
                          }
                          onClick={
                            () => this.onFormSubmit()
                          }
                        >
                          Submit
                        </button>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        }
        </div>
        
      </div>
    );
  }
}

const create = withTranslation()(Create);

export default create;
