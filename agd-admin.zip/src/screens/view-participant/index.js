import React, {  useState } from "react";
import { TITLE } from "../../constants/title";
import { BADGE } from "../../constants/bagde";
import { Link, Redirect } from "react-router-dom";
import { ENROLOPERATORLEVEL } from "../../constants/operatorLevel";
import { ENROLSTATUS } from "../../constants/enrolStatus";
import moment from "moment";
import { Navbar, Nav, Form } from "react-bootstrap";
import { withTranslation } from "react-i18next";
import Input from "../../components/inputField/inputField";
import { handleError } from "../../constants/error";
import { toast, ToastContainer } from "react-toastify";
import axios from "axios";
import config from "../../config/index";
import Header from "../../components/header/header";

const { API_BASE_URL } = config;
export const View=(props)=> {
  const [verifyError, setVerifyError] = useState();

  const token = localStorage.getItem("token");
  if (token == null) {
    return <Redirect to="/" />;
  }
  const onVerify = () => {
    debugger;

    const staffId = localStorage.getItem("staffId");
    console.log(staffId);
    if (props.location.state.participant.email != null) {
      axios({
        method: "post",
        url: API_BASE_URL + "verifyApi2?pageCode=" + 1,
        headers: {
          "content-type": "application/json",
          accept: "application/json",
          email: atob(localStorage.getItem("email")),
          lastSessionId: atob(localStorage.getItem("lsi")),

          Pragma: "no-cache"
        },
        data: {
          id: props.location.state.participant.id,
          operatorId: parseInt(staffId),
          enrolStatus: 3
        }
      })
        .then(response => {
          console.log(response.data);

          toast.success("E-mail envoyé pour l’émargement", {
            position: toast.POSITION.TOP_RIGHT,
            toastId: 4,
            autoClose: 3000
          });
          console.log("inside v");
        })
        .catch(err => handleError(err, props));
    } else {
      setVerifyError(
        "Veuillez mettre à jour l’adresse e-mail du participant avec l’icône bleue d’actualisation"
      );
    }
  };
  console.log("v_limit",props)
  const { t } = props
  return (
    <div>
    <Navbar bg="dark" variant="dark">
          <Navbar.Brand href="#">AGD</Navbar.Brand>
       </Navbar>
     <div class="agd-container">
        <ToastContainer />
        <div class="row">
          <div class="col-md-1 col-lg-2 col-xl-3"></div>
          <div class="col-md-10 col-lg-8 col-xl-6">
            <h2>
            {t("view.field_1")}:{" "}
              <strong class="text-info">
                {props.location.state.participant.name}{" "}{props.location.state.participant.surname}
              </strong>
            </h2>
            <strong>{t("view.field_2")}:</strong>{" "}
            {props.location.state.participant.id} | <strong>{t("view.field_3")}:</strong>{" "}
            {atob(localStorage.getItem("meetingName"))} 
            <br />
            <div className="d-flex justify-content-between mt-5">
              <div class=" text-left">
                <button href="#" onClick={onVerify} class="btn btn-warning">
                {t("view.field_4")}
                  <i
                    class="fa fa-envelope ml-2 text-danger"
                    aria-hidden="true"
                  ></i>
                </button>
              </div>
              <div class=" text-right">
                <Link
                  class="btn btn-secondary"
                  to={{
                    pathname: "/admin",
                    state: { 
                      ["lastActiveTab"]: props.location.state.activeKey,
                      ["lastLimit"]:props.location.state.lastLimit,
                             ["lastState"] :props.location.state.lastState
                  
                            }
                  }}
                >
                  Back
                </Link>
              </div>
            </div>
            <div class="text-danger text-left">{verifyError}</div>
            <br />
            <div class="card">
              <div class="card-body">
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_5")}</div>
                  <div class="col-sm-8">
                    {TITLE.map(
                      t =>
                        t.id === props.location.state.participant.title && (
                          <Input
                            type="text"
                            readonly
                            class="form-control-plaintext"
                            id="title"
                            name="title"
                            value={t.title}
                          />
                        )
                    )}
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_6")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="firstname"
                      name="firstname"
                      value={props.location.state.participant.name}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_7")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="lastname"
                      name="lastname"
                      value={props.location.state.participant.surname}
                    />
                  </div>
                </div>

                <hr />
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_8")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.address}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_9")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="zip"
                      name="zip"
                      value={props.location.state.participant.zipcode}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_10")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="city"
                      name="city"
                      value={props.location.state.participant.city}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_11")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="country"
                      name="country"
                      value={props.location.state.participant.countryCode}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_12")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="language"
                      name="language"
                      value={props.location.state.participant.languageCode}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                    <b>{t("view.field_13")}:</b>
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="email"
                      style={{ fontWeight: "bold" }}
                      name="email"
                      value={props.location.state.participant.email}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label"> {t("view.field_14")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="mobile"
                      name="mobile"
                      value={props.location.state.participant.mobilePhone}
                    />
                  </div>
                </div>
                <hr />

                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_15")}:
                  </div>
                  <div class="col-sm-8">
                    {BADGE.map(
                      b =>
                        b.id === props.location.state.participant.badge && (
                          <Input
                            type="text"
                            readonly
                            class="form-control-plaintext"
                            id="type"
                            name="type"
                            value={b.p_typeName}
                          />
                        )
                    )}
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label"> {t("view.field_16")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={
                        props.location.state.participant.votaccessCode
                          ? props.location.state.participant.votaccessCode
                          : "NA"
                      }
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
{t("view.field_17")}
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={
                        props.location.state.participant.lastVotaccessDigits
                          ? props.location.state.participant.lastVotaccessDigits
                          : "NA"
                      }
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_18")} :
                  </div>
                  <div class="col-sm-8">
                    {ENROLSTATUS.map(e =>
                      e.id === props.location.state.participant.enrolStatus ? (
                        <Input
                          type="text"
                          readonly
                          class="form-control-plaintext"
                          id="address"
                          name="address"
                          value={e.status_name}
                        />
                      ) : (
                        <div></div>
                      )
                    )}
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_19")}:
                  </div>
                  <div class="col-sm-8">
                    {ENROLOPERATORLEVEL.map(l =>
                      l.id ===
                      props.location.state.participant.enrolOpratorLevel ? (
                        <Input
                          type="text"
                          readonly
                          class="form-control-plaintext"
                          id="address"
                          name="address"
                          value={l.level}
                        />
                      ) : (
                        <div></div>
                      )
                    )}
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_20")}:
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={
                        (
                          props.location.state.participant.importedTime !== null
                        )
                          ? moment(
                              new Date(
                                props.location.state.participant.importedTime
                              )
                            ).format("MM/DD/YYYY, H:mm:ss")
                          : ""
                      }
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_21")}:
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={
                        (props.location.state.participant.createdTime !== null)
                          ? moment(
                              new Date(
                                props.location.state.participant.createdTime
                              )
                            ).format("MM/DD/YYYY, H:mm:ss")
                          : ""
                      }
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_22")}:
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={
                        (props.location.state.participant.updateTime == null)
                          ? moment(
                              new Date(
                                props.location.state.participant.updateTime
                              )
                            ).format("MM/DD/YYYY, H:mm:ss")
                          : ""
                      }
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_23")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.ordShares}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_24")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.ordVotes}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_25")}:
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.extrShares}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_26")}:
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.extrVotes}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_27")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.address}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                    {" "}
                    {t("view.field_28")}:
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.bankName}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_29")}:
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.bankAddress}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_30")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.bankCity}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_31")}:
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.repName}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_32")}:
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.repSurname}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_33")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.delegateCode}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_34")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.lastOperator}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_35")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={
                        !(
                          props.location.state.participant.operationTime ===
                          null
                        )
                          ? moment(
                              new Date(
                                props.location.state.participant.operationTime
                              )
                            ).format("MM/DD/YYYY, H:mm:ss")
                          : ""
                      }
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">{t("view.field_36")}:</div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.operationIp}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-4 col-form-label">
                  {t("view.field_37")}:
                  </div>
                  <div class="col-sm-8">
                    <Input
                      type="text"
                      readonly
                      class="form-control-plaintext"
                      id="address"
                      name="address"
                      value={props.location.state.participant.newResVote}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    
    </div>
  );
}
const view = withTranslation()(View);


export default view;
