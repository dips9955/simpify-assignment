import React, { Component } from "react";

export class ResetPassword extends Component {
  render() {
    return (
      <div>
        <div class="login-panel">
          <h2 class="text-center text-uppercase">Reset Password</h2>
          <form action="backoffice-management.html">
            <div class="form-group">
              <input
                type="password"
                class="form-control"
                id="pw"
                placeholder="New Password"
              />
              <small class="form-text text-danger"></small>
            </div>
            <div class="form-group">
              <input
                type="password"
                class="form-control"
                id="confirmPw"
                placeholder="Confirm Password"
              />
              <small class="form-text text-danger"></small>
            </div>
            <div class="row">
              <div class="col-12 text-right">
                <button type="submit" class="btn btn-primary">
                  Set Password
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default ResetPassword;
