import React, { Component } from "react";
import {Tabs,Tab} from "react-bootstrap"
import { withTranslation } from "react-i18next";

import Header from "../../components/header/header";
import {  Redirect } from "react-router-dom";
import { ToastContainer } from 'react-toastify';
import CommonTabs from "../adminPanel/common-tabs";
 class TabComponent extends Component {
   constructor(props){
     super(props)
     const token = localStorage.getItem("token");
     let loggedIn = true;
     if (token == null) {
       loggedIn = false;
     }
     this.state ={
      loggedIn,
      key:"pending",
      lastLimit:""
     }
   }
   componentDidMount=async ()=>{
     console.log("tab",this.props)
     debugger
  
    await this.setState({key:this.props.location?.state?.lastActiveTab})
    
   }
   
  render() {
    console.log("tab",this.props.location.state)
    if (this.state.loggedIn === false) {
      return <Redirect to="/" />;
    }
  const {t} = this.props
    return (
      <div >
                <Header {...this.props}
                  activeKey={this.state.key} 
                  lastLimit={this.props.location?.state?.lastLimit} 
                  logout={true} 
                />
                <ToastContainer />
        <Tabs  mountOnEnter unmountOnExit  style={{ fontSize: "25px"}} activeKey={this.state.key}  onSelect={(k) => this.setState({key:k})} id="all-tab">
        <Tab  eventKey="pending" title={t("common.title_3")}>
            <CommonTabs 
              {...this.props} 
              activeKey={this.state.key} lastLimit={this.props.location?.state?.lastLimit}  
              lastState={this.props.location?.state?.lastState}
              enrollStatusKey={2}
              isActive={true}
            />
          </Tab>
          <Tab eventKey="hold" title={t("common.title_4")}>
            <CommonTabs 
            {...this.props} 
            activeKey={this.state.key} 
            lastLimit={this.props.location?.state?.lastLimit}  
            lastState={this.props.location?.state?.lastState}
            enrollStatusKey={4}
              isActive={true}
          />
          </Tab>
          <Tab eventKey="all" title={t("common.title_5")} >
            <CommonTabs 
            {...this.props} 
            activeKey={this.state.key} 
            lastLimit={this.props.location?.state?.lastLimit}  
            lastState={this.props.location?.state?.lastState}
            enrollStatusKey={9}
            isActive={true}
          />
          </Tab>
         
        </Tabs>
      </div>
    );
  }
}
const tabComponent = withTranslation()(TabComponent)

export default tabComponent;
