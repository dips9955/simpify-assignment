import React, { Component } from "react";
import { Link } from "react-router-dom";
import Dropdown from "../../../components/dropdown/dropdown";
import Input from "../../../components/inputField/inputField";
import {
  
 // Pagination,
  Tooltip,
  OverlayTrigger
} from "react-bootstrap";
import Pagination from "react-js-pagination";
import axios from "axios";
import { withTranslation } from "react-i18next";
import config from "../../../config/index";
import FileModalComponent from "../../../components/modal/filemodal";
import { TITLE } from "../../../constants/title";
import { BADGE } from "../../../constants/bagde";
import { ENROLOPERATORLEVEL } from "../../../constants/operatorLevel";
import moment from "moment";
import VerifyModal from "../../../components/modal/verifyModal";
import SendEmailModal from "../../../components/modal/sendEmailModal";
import SummaryModal from "../../../components/modal/summaryModal";
import { ACTIONS } from "../../../constants/action";
import UpdateModal from "../../../components/modal/updateModal";
import {  handleGetlistError } from "../../../constants/error";
import Sorting from "../../../components/sort/sorting";
import { Spinner } from "../../../components/spinner/spinner";
import { PUSH } from "../../../constants/pushFlag";
import { ENROLSTATUS } from "../../../constants/enrolStatus";
import Header from "../../../components/header/header";
import Switch from "react-switch";
const { API_BASE_URL } = config;
export class CommonTabs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [],
      id: "",
      fName: "",
      lName: "",
      operatedId: "",
      lastVotaAccessDigit: "",
      email: "",
      errorMsg: "",
      currentPage: 1,
      postPerPage: 5,
      selectValue: 0,
      sortBy: "",
      asc: 0,
      desc: 0,
      participant: null,
      verifyShow: false,
      sendEmailShow: false,
      isSearchList: false,
      updateShow: false,
      summaryShow: false,
      sortedData: null,
      show: false,
      search: null,
      limit: 0,
      isSearching: false,
      pageCode: null,
      enrolStatus: 9,
      formErrorsFName: null,
      formErrorsLName: null,
      formErrorOperatedId: null,
      loader: false,
      backgroundColor: false,
      enrollStatusKeyState : this.props.enrollStatusKey,
      inscription:false,
      online:false,
      type:0,
      mechanism:0,
      title:0,
      activePage:1,
      enrolStatusVerify:null,
      totalCount:null
    };
    this.handleShow = this.handleShow.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }
  limit = this.props.lastLimit != undefined ? this.props.lastLimit: 0;
  enrollStatusKey = this.props.enrollStatusKey
  
  componentDidMount = (e) => {
    debugger
  console.log("enrollStatusKey",this.props.enrollStatusKey)
    const query =
      localStorage.getItem("searchUrl") != null &&
      atob(localStorage.getItem("searchUrl"));

    console.log("query", query);
    const { sortBy, asc, desc } = this.state;
    console.log("activeKeySS", this.props.activeKey);
    console.log("activeKeyLocal", localStorage.getItem("activeTabkey"));
   
    
      if(this.props.activeKey==localStorage.getItem("activeTabkey")){
      const params = new URLSearchParams(query);
      this.setState(
        {
          fName: params.get("name")?params.get("name"):"",
          lName: params.get("surname")? params.get("surname"):"",
          selectValue: params.get("enrolOpratorLevel")?params.get("enrolOpratorLevel"):0,
          operatedId: params.get("lastOperator")?params.get("lastOperator"):"",
          id: params.get("id")?params.get("id"):"",
          email: params.get("email")?params.get("email"):"",
          lastVotaAccessDigit: params.get("lastVotaccessDigits")?params.get("lastVotaccessDigits"):"",
          sortBy: params.get("sortBy")?params.get("sortBy"):this.props.lastState?.sortBy?this.props.lastState.sortBy:"",
          asc: params.get("asc")?params.get("asc"):this.props.lastState?.asc?this.props.lastState.asc:0,
          desc: params.get("desc")?params.get("desc"):this.props.lastState?.desc?this.props.lastState.desc:0,
          type: params.get("type")?params.get("type"):0,
          title: params.get("title")?params.get("title"):0,
          enrolStatus: params.get("enrolStatus")?params.get("enrolStatus"):9,
          mechanism: params.get("push")?params.get("push"):0,
          // inscription: params.get("agdUser")?params.get("agdUser"):false,
          // online: params.get("loginToGm")?params.get("loginToGm"):false,

          isSearchList:this.props.lastState?.isSearchList ?this.props.lastState.isSearchList:false

         // enrollStatusKeyState : params.get("enrolStatus")?params.get("enrolStatus"):this.props.enrollStatusKey
        },
        () => this.getList(e, this.limit, query, sortBy, asc, desc)
      );
      
    }else if( this.props.lastState?.sortBy){
      this.getList(
        e,
        this.limit,
        "",
        this.props.lastState.sortBy,
        this.props.lastState.asc,
        this.props.lastState.desc
      )
      
    } else {
      this.getList(e,this.limit);
    }
  }
  
  handlePageChange=(pageNumber)=> {
    console.log(`active page is ${pageNumber}`);
    const { sortBy, asc, desc } = this.state;

    this.limit=(pageNumber*20)-20
    this.setState({activePage: pageNumber});
    this.props.lastState?.sortBy 
    ? this.getList(
        "",
        this.limit,
        "",
        this.props.lastState.sortBy,
        this.props.lastState.asc,
        this.props.lastState.desc
      )
    : this.getList("", this.limit, "", sortBy, asc, desc);
  }

  limitNext = (e) => {
    const { sortBy, asc, desc } = this.state;
    this.limit = this.limit + 20;
    console.log("limitNext", this.limit);
    
      this.props.lastState?.sortBy 
      ? this.getList(
          e,
          this.limit,
          "",
          this.props.lastState.sortBy,
          this.props.lastState.asc,
          this.props.lastState.desc
        )
      : this.getList(e, this.limit, "", sortBy, asc, desc);
  }
  limitPrev = (e) => {
    this.setState({ errorMsg: "" });
    const { sortBy, asc, desc } = this.state;

    if (this.limit > 0) {
      this.limit = this.limit - 20;
      console.log("limitPrev", this.limit);
        this.props.lastState?.sortBy
        ? this.getList(
            e,
            this.limit,
            "",
            this.props.lastState.sortBy,
            this.props.lastState.asc,
            this.props.lastState.desc
          )
        : this.getList(e, this.limit, "", sortBy, asc, desc);
    }
  }
  
  getList = async (e, limit, query, SortBy, Asc, Desc) => {
  
    if (e) {
      e.preventDefault();
    }
   debugger;

    this.setState({errorMsg:""})
    let SORTBY = SortBy ? SortBy : "";
    let ASC = Asc ? Asc : 0;
    let DESC = Desc ? Desc : 0;
   await this.setState({ sortBy: SORTBY, asc: ASC, desc: DESC });
console.log("limit",this.limit)
    const meetingId = atob(localStorage.getItem("meetingId"));
    const {
      fName,
      lName,
      operatedId,
      selectValue,
      id,
      email,
      lastVotaAccessDigit,
      sortBy,
      asc,
      desc,
      isSearchList,
      title,
      type,
      enrolStatus,
      online,
      inscription,
      mechanism
      
    } = this.state;
    
    const es= enrolStatus!=9? enrolStatus:this.props.enrollStatusKey

    console.log(fName, lName, operatedId, selectValue);
   
    const SEARCH_URL =
      API_BASE_URL +
      "participants/getList?limit=20&offset=" +
      String(limit) +
      "&enrolStatus="+
     //this.props.enrollStatusKey+
     es+
     //9+
      "&meetingId=" +
      parseInt(meetingId) +
      "&name=" +
      fName +
      "&surname=" +
      lName +
      "&enrolOpratorLevel=" +
      parseInt(selectValue) +
      "&lastOperator=" +
      operatedId +
      "&id=" +
      id +
      "&email=" +
      email +
      "&lastVotaccessDigits=" +
      lastVotaAccessDigit+
      "&sortBy=" +
      sortBy +
      "&ASC=" +
      asc +
      "&DESC=" +
      desc+
      "&type="+
      type+
      "&push="+
      mechanism+
      "&title="+
      title+
      "&agdUser="+
      inscription+
     // true+
      "&loginToGm="+
      online
      ;

    if(isSearchList){
    localStorage.setItem("searchUrl", btoa(SEARCH_URL));
    //document.getElementById("search-addon").classList.add("active");

    }
   
    this.setState({ loader: true });
    axios({
      method: "get",
      url: query || SEARCH_URL,

      headers: {
        "content-type": "application/json",
        accept: "application/json",
        email: atob(localStorage.getItem("email")),
        lastSessionId: atob(localStorage.getItem("lsi")),

        Pragma: "no-cache"
      }
    })
      .then(response => {
  
        console.log("search", response.data.participantList);
        this.setState({ list: response.data.participantList });
        this.setState({ totalCount: response.data.count });

        this.setState({ loader: false });
      })
      .catch(err => {
        handleGetlistError(err, this.props);
        this.setState({ searchList: null });
        this.setState({ list: [] });
        this.setState({ errorMsg: "Fiche(s) pas retrouvé" });

      });
  };
  
  handleClose = (e) => {
    const { sortBy, asc, desc } = this.state;
    this.props.lastState?.sortBy
    ? this.getList(
        e,
        this.limit,
        "",
        this.props.lastState.sortBy,
        this.props.lastState.asc,
        this.props.lastState.desc
      )
    : this.getList(e, this.limit, "", sortBy, asc, desc);
    this.setState({ show: false });
  };
  handleShow = item => {
    debugger;
    this.setState({ participant: item });
    this.setState({ show: true });
  };
  handleVerifyClose = (e) => {
    const { sortBy, asc, desc } = this.state;
    this.props.lastState?.sortBy
    ? this.getList(
        e,
        this.limit,
        "",
        this.props.lastState.sortBy,
        this.props.lastState.asc,
        this.props.lastState.desc
      )
    : this.getList(e, this.limit, "", sortBy, asc, desc);
    this.setState({ verifyShow: false });
  };
  handleVerifyShow = (item, pageCode, enrolStatus) => {
    debugger;
    this.setState({ participant: item });
    this.setState({ verifyShow: true });
    this.setState({ pageCode: pageCode });
    this.setState({ enrolStatusVerify: enrolStatus });
  };
  handleSendEmailClose = (e) => {
    const { sortBy, asc, desc } = this.state;
    this.props.lastState?.sortBy
    ? this.getList(
        e,
        this.limit,
        "",
        this.props.lastState.sortBy,
        this.props.lastState.asc,
        this.props.lastState.desc
      )
    : this.getList(e, this.limit, "", sortBy, asc, desc);
    this.setState({ sendEmailShow: false });
  };
  handleSendEmailShow = (item, pageCode, enrolStatus) => {
    debugger;
    this.setState({ participant: item });
    this.setState({ sendEmailShow: true });
    this.setState({ pageCode: pageCode });
    this.setState({ enrolStatusVerify: enrolStatus });
  };
  handleUpdateClose = (e) => {
    const { sortBy, asc, desc } = this.state;
    this.props.lastState?.sortBy
    ? this.getList(
        e,
        this.limit,
        "",
        this.props.lastState.sortBy,
        this.props.lastState.asc,
        this.props.lastState.desc
      )
    : this.getList(e, this.limit, "", sortBy, asc, desc);
    this.setState({ updateShow: false });
  };
  handleUpdateShow = item => {
    debugger;
    this.setState({ participant: item });
    this.setState({ updateShow: true });
  };
  handleSummaryClose = e => {
    const { sortBy, asc, desc } = this.state;
    this.props.lastState?.sortBy
    ? this.getList(
        e,
        this.limit,
        "",
        this.props.lastState.sortBy,
        this.props.lastState.asc,
        this.props.lastState.desc
      )
    : this.getList(e, this.limit, "", sortBy, asc, desc);
    this.setState({ summaryShow: false });
  };
  handleSummaryShow = item => {
    // debugger;
    this.setState({ participant: item });
    this.setState({ summaryShow: true });
  };
  handleCallback = (name, value) => {
    
    if (name === "fName") {
      this.setState({ fName: value });
      this.setState({ backgroundColor: true });
      localStorage.setItem("activeTabkey",this.props.activeKey);
          this.setState({isSearchList:true})
    //document.getElementById("search-addon").classList.add("active");

    } else if (name === "lName") {
      this.setState({ lName: value });
      localStorage.setItem("activeTabkey",this.props.activeKey);
          this.setState({isSearchList:true})
    //document.getElementById("search-addon").classList.add("active");

    } else if (name === "operatedId") {
      this.setState({ operatedId: value });
      localStorage.setItem("activeTabkey",this.props.activeKey);
    //document.getElementById("search-addon").classList.add("active");
    this.setState({isSearchList:true})
    } else if (name === "search") {
      this.setState({ search: value });
      localStorage.setItem("activeTabkey",this.props.activeKey);
    //document.getElementById("search-addon").classList.add("active");
    this.setState({isSearchList:true})
    } else if (name === "id") {
      this.setState({ id: value });
      localStorage.setItem("activeTabkey",this.props.activeKey);
          this.setState({isSearchList:true})
    //document.getElementById("search-addon").classList.add("active");
  } else if (name === "email") {
      this.setState({ email: value });
      localStorage.setItem("activeTabkey",this.props.activeKey);
          this.setState({isSearchList:true})
    //document.getElementById("search-addon").classList.add("active");
  } else if (name === "lastVotaAccessDigit") {
      this.setState({ lastVotaAccessDigit: value });
      localStorage.setItem("activeTabkey",this.props.activeKey);
          this.setState({isSearchList:true})
    //document.getElementById("search-addon").classList.add("active");
  }
  this.getList("",0)
  };

  handleOnChange=(e,ddValue)=>{
   // console.log(e.target.value);

    if(ddValue=="type"){
      console.log(e.target.value);
      this.setState({type:e.target.value})
      this.getList(e,0)
    //document.getElementById("search-addon").classList.add("active");

    localStorage.setItem("activeTabkey",this.props.activeKey);
    this.setState({isSearchList:true})

    }else if(ddValue=="title"){
      console.log(e.target.value);
      this.setState({title:e.target.value})
      this.getList(e,0)
    //document.getElementById("search-addon").classList.add("active");
    this.setState({isSearchList:true})

    localStorage.setItem("activeTabkey",this.props.activeKey);

    }else if(ddValue=="enrolStatus"){
      console.log(e.target.value);
      this.setState({enrolStatus:e.target.value})
      this.getList(e,0)
    //document.getElementById("search-addon").classList.add("active");
    this.setState({isSearchList:true})
    localStorage.setItem("activeTabkey",this.props.activeKey);

      
    }else if(ddValue=="mechanism"){
      console.log(e.target.value);
      this.setState({mechanism:e.target.value})
      this.getList(e,0)
    //document.getElementById("search-addon").classList.add("active");

    this.setState({isSearchList:true})
    localStorage.setItem("activeTabkey",this.props.activeKey);
      
    }else if(ddValue=="inscription"){
      this.setState({inscription:!this.state.inscription})

      this.getList("",0)
    //document.getElementById("search-addon").classList.add("active");
    this.setState({isSearchList:true})
    localStorage.setItem("activeTabkey",this.props.activeKey);

    }else if(ddValue=="online"){
      this.setState({online:!this.state.online})

      this.getList("",0)
    //document.getElementById("search-addon").classList.add("active");
    this.setState({isSearchList:true})
    localStorage.setItem("activeTabkey",this.props.activeKey);


    }
    else{
    this.setState({
      selectValue: e.target.value
    });
          this.setState({isSearchList:true})
          this.getList(e,0)
    //document.getElementById("search-addon").classList.add("active");
    localStorage.setItem("activeTabkey",this.props.activeKey);

  }
  
  }
  
  onRefresh = async (e) => {

    await this.setState({
      backgroundColor: false,
      fName: "",
      lName: "",
      selectValue: 0,
      operatedId: "",
      searchList: null,
      id: "",
      email: "",
      lastVotaAccessDigit: "",
      errorMsg: "",
      sortBy: "",
      asc: 0,
      desc: 0,
      type:0,title:0,mechanism:0,enrolStatus:9,inscription:false,online:false,isSearchList:false
    });
   // document.getElementById("search-addon").classList.remove("active");

    this.getList(e,0);
    localStorage.removeItem("searchUrl");

  };
  
  render() {
    const { list, errorMsg, loader } = this.state;
    const { t } = this.props;
  //   console.log("commonTabs props", this.props);
  // console.log("enrollStatusKey_render",this.props.enrollStatusKey)
  // console.log("ActiveKey_render",this.props.activeKey)
    return (
      <div className="agd-container" key={this.props.enrollStatusKey}>
                {/* <Header {...this.props}/> */}

      {this.state.participant != null && (
        <SummaryModal
          onHide={this.handleSummaryClose}
          show={this.state.summaryShow}
          Props={this.props}
        />
      )}
        {this.state.participant != null && (
          <FileModalComponent
            participant={this.state.participant}
            onHide={this.handleClose}
            show={this.state.show}
            Props={this.props}
          />
        )}
        {this.state.participant != null && (
          <VerifyModal
            participant={this.state.participant}
            pageCode={this.state.pageCode}
            enrolStatus={this.state.enrolStatusVerify}
            hidden={this.props.enrollStatusKey===2?false:this.props.enrollStatusKey===4?true:false}
            onHide={this.handleVerifyClose}
            show={this.state.verifyShow}
            Props={this.props}
          />
        )}
        {this.state.participant != null && (
          <SendEmailModal
            participant={this.state.participant}
            pageCode={this.state.pageCode}
            enrolStatus={this.state.enrolStatusVerify}
            onHide={this.handleSendEmailClose}
            show={this.state.sendEmailShow}
            Props={this.props}
          />
        )}
        {this.state.participant != null && (
          <UpdateModal
            participant={this.state.participant}
            onHide={this.handleUpdateClose}
            show={this.state.updateShow}
            Props={this.props}
          />
        )}
        {
        this.props.isActive &&
        <form onSubmit={e =>{this.getList(e,0);
          localStorage.setItem("activeTabkey",this.props.activeKey);
          this.setState({isSearchList:true})
    }}>
          <div class="search-bar">
            <div class="flex-disp">
            <div>
            
            {t("common.field_7")}:
                <br />
                <Input
                  id="id"
                  type="number"
                  name="id"
                  min="0"
                  class="form-control rounded"
                  placeholder={t("common.field_7")}
                 
                  style={{
                    backgroundColor: this.state.id ? "lightYellow" : "transparent ",
                   width:"80px"

                  }}
                  value={this.state.id}
                  parentCallback={this.handleCallback}
                />
              </div>
              <div>
            {t("common.field_13")} :<br/>
            <select 
                value={this.state.type}
                class="form-control" 
                onChange={(e)=>this.handleOnChange(e,"type")} 
                style={{
                  backgroundColor: this.state.type !=0 ? "lightYellow" : "transparent ",
                 width:"80px"
                }}
                >
              <option value="">Select</option>

                {
                  BADGE.map(b =>
                <option value={b.id}>{b.badge_frenchName}</option>
                    
                    )
                }

            </select>
      </div>
      <div>
      {t("common.field_14")}:<br/>
            <select 
                value={this.state.title}
                class="form-control" 
                onChange={(e)=>this.handleOnChange(e,"title")}
                style={{
                  backgroundColor: this.state.title !=0 ? "lightYellow" : "transparent ",
                 width:"100px"
                }}
                >
              <option value="">Select</option>

                  {
                    TITLE.map(t =>
              <option value={t.id}>{t.title}</option>
                      
                      )
                  }
             
            </select>
      </div>
      <div>
      {t("common.field_8")}:
                <br />
                <Input
                  id="fName"
                  type="search"
                  name="fName"
                  class="form-control rounded "
                  style={{
                    backgroundColor:
                      this.state.fName != "" ? "lightYellow" : "transparent "
                  }}
                  placeholder={t("common.field_8")}
                  value={this.state.fName}
                  parentCallback={this.handleCallback}
                />
              </div>
              <div>
              {t("common.field_9")}:
                <br />
                <Input
                  id="lName"
                  type="search"
                  name="lName"
                  class="form-control rounded"
                  value={this.state.lName}
                  style={{
                    backgroundColor: this.state.lName ? "lightYellow" : "transparent "
                  }}
                  placeholder={t("common.field_9")}
                  parentCallback={this.handleCallback}
                />
              </div>
              <div>
              {t("common.field_11")}:
                <br />
                <Input
                  id="email"
                  type="email"
                  name="email"
                  class="form-control rounded"
                  placeholder={t("common.field_11")}
                  aria-label="Search"
                  value={this.state.email}
                  style={{
                    backgroundColor: this.state.email ? "lightYellow" : "transparent "
                  }}
                  parentCallback={this.handleCallback}
                />
              </div>
              <div>
              {t("common.field_12")}:
                <br />
                <Input
                  id="operatedId"
                  type="search"
                  name="lastVotaAccessDigit"
                  class="form-control rounded"
                  placeholder={t("common.field_12")}
                  aria-label="Search"
                  value={this.state.lastVotaAccessDigit}
                  style={{
                    backgroundColor: this.state.lastVotaAccessDigit
                      ? "lightYellow"
                      : "transparent "
                  }}
                  parentCallback={this.handleCallback}
                />
              </div>
              <Dropdown
                {...this.props}
                all="Select"
                l1="L1"
                l2="L2"
                l3={t("common.field_6")}
                selectValue={this.state.selectValue}
                handleOnChange={this.handleOnChange.bind(this)}
              />
              
              <div>
              {t("common.field_10")}:
                <br />
                <Input
                  id="operatedId"
                  type="search"
                  name="operatedId"
                  class="form-control rounded"
                  placeholder={t("common.field_10")}
                  aria-label="Search"
                  value={this.state.operatedId}
                  style={{
                    backgroundColor: this.state.operatedId
                      ? "lightYellow"
                      : "transparent"
                  }}
                  parentCallback={this.handleCallback}
                />
              </div>
              
      
        {
          this.enrollStatusKey==9 ?
        <>
        <div>
        {t("common.field_22")}:<br/>
            <select 
                value={this.state.enrolStatus}
                class="form-control" 
                onChange={(e)=>this.handleOnChange(e,"enrolStatus")} 
                style={{
                  backgroundColor: this.state.enrolStatus !=9 ? "lightYellow" : "transparent "
                }}
                >
               <option value={9}>Select </option>

            {
            ENROLSTATUS.map(e =>
            <option value={e.id}>{e.status_name}</option>
                
                )
            }
            </select>
      </div>
      <div>
      {t("common.field_23")}:<br/>
            <select 
                value={this.state.mechanism}
                class="form-control" 
                onChange={(e)=>this.handleOnChange(e,"mechanism")} 
                style={{
                  backgroundColor: this.state.mechanism !=0 ? "lightYellow" : "transparent "
                }}
                >
              <option value={0}>Select </option>

                {
                 PUSH.map(p =>
                <option value={p.id}>{p.pushFlag}</option>
                    
                    )
                }
            </select>
      </div>
      </>
      :<></>
              }
      
              
             
              
              
              
              {/* <div>
                <button
                  class="input-group-text border-0 btn btn-info "
                  id="search-addon"
                  type="submit"
                  href="#"
                  onClick={
                    e => {this.getList(e,0);
                          localStorage.setItem("activeTabkey", this.props.activeKey);
                        this.setState({isSearchList:true})
                    }
                  }
                >
                  <i class="fa fa-search " aria-hidden="true"></i>
                </button>
              </div> */}
              <div>
                <a
                  class="input-group-text border-0 btn btn-info"
                  href="#"
                  onClick={() => this.onRefresh()}
                >
                  {t("common.field_27")}
                </a>
              </div>
              {
                this.enrollStatusKey == 9?
                <div>
                <a
                  class="input-group-text border-0 btn btn-info"
                  href="#"
                  onClick={() => this.handleSummaryShow(list)}
                >
                  {t("common.field_28")}
                  
                </a>
              </div>:<></>
              }
            </div>
          </div>
        </form>
        }
        <div>
         
          {this.enrollStatusKey == 9 ?
       
          <div class="search-bar flex-disp">
            <div>
            
            {t("common.field_24")}:
              <br/>
              <Switch onColor="#EAD910"  onChange={(e)=>this.handleOnChange(e,"inscription")} checked={this.state.inscription} />
              </div>
            <div>
            {t("common.field_26")}:
              <br/>
              <Switch onColor="#EAD910" onChange={(e)=>this.handleOnChange(e,"online")} checked={this.state.online} />
              </div>
            
          </div>
          :<></>
          }
           <div class="text-left">
            {
          this.enrollStatusKey == 2 ?  <h2>{t("common.title_3")}</h2>: this.enrollStatusKey == 4 ? <h2>{t("common.title_4")}</h2>:this.enrollStatusKey == 9 ?  <h2>{t("common.title_5")}</h2>:<></>
            }
          </div>
        
          </div>
        <div class="detail-info">
          <div class="table-responsive">
            <table
              class="table table-bordered table-striped"
              style={{ borderCollapse: "collapse", width: "100%" }}
              id="pending"
            >
              <thead>
              {

                <tr class="bg-dark text-white">
                  <th class="position-relative">
                  {t("common.field_7")}
                    <div class="spacer"></div>
                    <Sorting
                     
                      handleGetlistSortByAsc={e =>
                        this.getList(e, this.limit, "", "id", "1", "0")
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(e, this.limit, "", "id", "0", "1")
                      }
                    />
                  </th>
                  <th class="position-relative">
                  {t("common.field_13")}
                    <div class="spacer"></div>
                    <Sorting
                    
                      handleGetlistSortByAsc={e =>
                        this.getList(e, this.limit, "", "type", "1", "0")
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(e, this.limit, "", "type", "0", "1")
                      }
                    />
                  </th>
                  <th class="position-relative">
                  {t("common.field_14")}
                    <div class="spacer"></div>
                    <Sorting
                 
                      handleGetlistSortByAsc={e =>
                        this.getList(e, this.limit, "", "title", "1", "0")
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(e, this.limit, "", "title", "0", "1")
                      }
                    />
                  </th>
                  <th class="position-relative">
                  {t("common.field_8")}
                    <div class="spacer"></div>
                    <Sorting
                  
                      handleGetlistSortByAsc={e =>
                        this.getList(e, this.limit, "", "name", "1", "0")
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(e, this.limit, "", "name", "0", "1")
                      }
                    />
                  </th>
                  <th class="position-relative">
                  {t("common.field_9")}
                    <div class="spacer"></div>
                    <Sorting
                   
                      handleGetlistSortByAsc={e =>
                        this.getList(e, this.limit, "", "surname", "1", "0")
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(e, this.limit, "", "surname", "0", "1")
                      }
                    />
                  </th>
                  <th class="position-relative">
                  {t("common.field_11")}
                    <div class="spacer"></div>
                    <Sorting
                  
                      handleGetlistSortByAsc={e =>
                        this.getList(e, this.limit, "", "email", "1", "0")
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(e, this.limit, "", "email", "0", "1")
                      }
                    />
                  </th>
                  <th class="position-relative">
                  {t("common.field_12")}
                    <div class="spacer"></div>
                    <Sorting
                   
                      handleGetlistSortByAsc={e =>
                        this.getList(e,this.limit,
                          "",
                          "lastVotaccessDigits",
                          "1",
                          "0"
                        )
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(
                          e,
                          this.limit,
                          "",
                          "lastVotaccessDigits",
                          "0",
                          "1"
                        )
                      }
                    />
                  </th>

                  <th class="position-relative">
                  {t("common.field_15")}
                    <div class="spacer"></div>
                    <Sorting
                    
                      handleGetlistSortByAsc={e =>
                        this.getList(e, this.limit, "", "address", "1", "0")
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(e, this.limit, "", "address", "0", "1")
                      }
                    />
                  </th>
                 
                  <th class="position-relative">
                  {t("common.field_17")}
                    <div class="spacer"></div>
                    <Sorting
                   
                      handleGetlistSortByAsc={e =>
                        this.getList(
                          e,
                          this.limit,
                          "",
                          "enrolOpratorLevel",
                          "1",
                          "0"
                        )
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(
                          e,
                          this.limit,
                          "",
                          "enrolOpratorLevel",
                          "0",
                          "1"
                        )
                      }
                    />
                  </th>
                  <th class="position-relative">
                  {t("common.field_10")}
                    <div class="spacer"></div>
                    <Sorting
                    
                      handleGetlistSortByAsc={e =>
                        this.getList(
                          e,
                          this.limit,
                          "",
                          "lastOperator",
                          "1",
                          "0"
                        )
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(
                          e,
                          this.limit,
                          "",
                          "lastOperator",
                          "0",
                          "1"
                        )
                      }
                    />
                  </th>
                  <th class="position-relative">
                  {t("common.field_18")}
                  
                    <div class="spacer"></div>
                    <div class="spinners">
                      
                      <Sorting
                        
                        handleGetlistSortByAsc={e =>
                          this.getList(
                            e,
                            this.limit,
                            "",
                            "operationTime",
                            "1",
                            "0"
                          )
                        }
                        handleGetlistSortByDesc={e =>
                          this.getList(
                            e,
                            this.limit,
                            "",
                            "operationTime",
                            "0",
                            "1"
                          )
                        }
                      />
                    </div>
                  </th>
                  {
                  this.enrollStatusKey==2 || this.enrollStatusKey==4 ?
                  <>
                  <th class="position-relative">
                  {t("common.field_16")} 
                    <div class="spacer"></div>
                    <div class="spinners">
                   
                      <Sorting
                     
                      handleGetlistSortByAsc={e =>
                        this.getList(e, this.limit, "", "createdTime", "1", "0")
                      }
                      handleGetlistSortByDesc={e =>
                        this.getList(e, this.limit, "", "createdTime", "0", "1")
                      }
                    />
                    </div>
                  </th>
                  <th>
                  {t("common.field_19")}
                  </th>
                  <th class="position-relative">
                  {t("common.field_20")}
                    <div class="spacer"></div>
                    <Sorting 
                  
                      handleGetlistSortByAsc={(e)=> this.getList(e,this.limit,"","actionId","1","0")}
                      handleGetlistSortByDesc={(e) => this.getList(e,this.limit,"","actionId","0","1")}
                      />
                  </th>
                  <th>{t("common.field_21")}</th>
                  </>
                  :this.enrollStatusKey==9?
                  <>
                  <th class="position-relative">
                  {t("common.field_22")}
                  <div class="spacer"></div>
                  <Sorting
                 
                    handleGetlistSortByAsc={e =>
                      this.getList(e, this.limit, "", "enrolStatus", "1", "0")
                    }
                    handleGetlistSortByDesc={e =>
                      this.getList(e, this.limit, "", "enrolStatus", "0", "1")
                    }
                  />
                </th>
                <th class="position-relative">
                {t("common.field_23")}
                  <div class="spacer"></div>
                  <Sorting
                    handleGetlistSortByAsc={e =>
                      this.getList(e, this.limit, "", "push", "1", "0")
                    }
                    handleGetlistSortByDesc={e =>
                      this.getList(e, this.limit, "", "push", "0", "1")
                    }
                  />
                </th>
                <th class="position-relative">{t("common.field_24")}
                <div class="spacer"></div>
                  <Sorting
                    handleGetlistSortByAsc={e =>
                      this.getList(e, this.limit, "", "agdUser", "1", "0")
                    }
                    handleGetlistSortByDesc={e =>
                      this.getList(e, this.limit, "", "agdUser", "0", "1")
                    }
                  />
                </th>
                <th class="position-relative">{t("common.field_25")}
                <div class="spacer"></div>
                  <Sorting
                    handleGetlistSortByAsc={e =>
                      this.getList(e, this.limit, "", "termsAndConditionsSigned", "1", "0")
                    }
                    handleGetlistSortByDesc={e =>
                      this.getList(e, this.limit, "", "termsAndConditionsSigned", "0", "1")
                    }
                  />
                </th>
                <th class="position-relative">{t("common.field_26")}
                <div class="spacer"></div>
                  <Sorting
                    handleGetlistSortByAsc={e =>
                      this.getList(e, this.limit, "", "loginToGm", "1", "0")
                    }
                    handleGetlistSortByDesc={e =>
                      this.getList(e, this.limit, "", "loginToGm", "0", "1")
                    }
                  />
                </th>
                <th class="position-relative">
                {t("common.field_20")}
                 
              
                </th>
                </>
                :<div></div>
                }


                </tr>
                
              }
              </thead>
              
              <tbody>
                {loader || errorMsg ? (
                  <tr>
                    <td class="text-center " colSpan={this.enrollStatusKey==2 || this.enrollStatusKey==4 ?15:19}>
                      {errorMsg ? (
                        <div className="text-danger">{errorMsg}</div>
                      ) : (
                        <div>
                          <Spinner height={60} width={60} visible={true} />
                          <br />
                          Please wait
                        </div>
                      )}
                    </td>
                  </tr>
                ) : (
                  list.map(participant => (
                    <tr>
                      <td class="text-right">
                      <Link
                          to={{
                            pathname: "/view",
                            state: {participant,["activeKey"]:this.props.activeKey,["lastLimit"]:this.limit,["lastState"]: this.state} 
                          }}
                        >
                      {participant.id}
                      </Link>
                      </td>
                      

                      <td class="text-center">
                        {BADGE.map(b =>
                          b.id === parseInt(participant.type) ? (
                            <div class={`badge badge-${b.id}`}>
                              {b.badge_frenchName}
                            </div>
                          ) : (
                            <div></div>
                          )
                        )}
                      </td>

                      <td class="text-center">
                        {TITLE.map(t =>
                          t.id === participant.title ? (
                            <div>{t.title}</div>
                          ) : (
                            <div></div>
                          )
                        )}
                      </td>
                      <td class="text-center">{participant.name}</td>
                      <td class="text-center">
                        
                          {participant.surname}
                        
                      </td>
                      <td class="text-center ">
                        <OverlayTrigger
                          key={"top"}
                          placement={"top"}
                          overlay={
                            <Tooltip>
                              <strong>{participant.email}</strong>.
                            </Tooltip>
                          }
                        >
                          <div class="truncate">{participant.email}</div>
                        </OverlayTrigger>
                      </td>
                      <td class="text-center">
                        {participant.lastVotaccessDigits}
                      </td>
                      <td>{participant.address}</td>
                    
                    
                      <td class="text-center">
                        {ENROLOPERATORLEVEL.map(l =>
                          l.id === participant.enrolOpratorLevel ? (
                            <div>{l.level}</div>
                          ) : (
                            <div></div>
                          )
                        )}
                      </td>
                      <td>{participant.lastOperator}</td>
                      <td>
                        {(participant.operationTime !== null) ? (
                          moment(new Date(participant.operationTime)).format(
                            "MM/DD/YYYY, H:mm:ss"
                          )
                        ) : (
                          <div></div>
                        )}
                      </td>
                      {
                  this.enrollStatusKey==2 || this.enrollStatusKey==4 ?
                  <>
                      <td>
                        {(participant.createdTime !== null) ? (
                          moment(new Date(participant.createdTime)).format(
                            "MM/DD/YYYY, H:mm:ss"
                          )
                        ) : (
                          <div></div>
                        )}
                      </td>
                      <td class="text-center">
                        <a
                          href="#"
                          class="btn btn-sm btn-secondary "
                          data-toggle="modal"
                          data-target="#uploadModal"
                          onClick={() => this.handleShow(participant)}
                        >
                          <i class="fa fa-cloud-upload" aria-hidden="true"></i>
                        </a>
                      </td>
                      <td class="text-center">
                        {
                          ACTIONS.map(a => {
                            if (a.id === participant.actionId) {
                              if (participant.actionId === 1) {
                                return (
                                  <a
                                    href="#"
                                    class="btn btn-sm btn-warning"
                                    onClick={() =>
                                      this.handleSendEmailShow(
                                        participant,
                                        a.pageCode,
                                        a.enrolStatus
                                      )
                                    }
                                  >
                                    <i
                                      class="fa fa-envelope"
                                      aria-hidden="true"
                                    ></i>
                                  </a>
                                );
                              } else {
                                return (
                                  <a
                                    href="#"
                                    class={`btn btn-sm ${a.class_name}`}
                                    onClick={() =>
                                      this.handleVerifyShow(
                                        participant,
                                        a.pageCode,
                                        a.enrolStatus
                                      )
                                    }
                                  >
                                    <i
                                      class={`fa fa-${a.actionName}`}
                                      aria-hidden="true"
                                    ></i>
                                  </a>
                                );
                              }
                            } else {
                              return <div></div>;
                            }
                          })
                       }
                      </td>
                      <td class="text-center ">
                        <Link
                          class="btn btn-sm btn-info "
                          onClick={() => this.handleUpdateShow(participant)}
                        >
                          <i class="fa fa-pencil" aria-hidden="true"></i>
                        </Link>
                      </td>
                      </>: 
                      this.enrollStatusKey==9?
                      <>
                      <td class="text-center">
                        {ENROLSTATUS.map(e =>
                          e.id === participant.enrolStatus ? (
                            <div>{e.status_name}</div>
                          ) : (
                            <div></div>
                          )
                        )}
                      </td>
                      <td class="text-center">
                        {PUSH.map(p =>
                          p.id === participant.push ? (
                            <div>{p.pushFlag}</div>
                          ) : (
                            <div></div>
                          )
                        )}
                      </td>
                      {participant.agdUser === true ? <td>AGD</td> : <td></td>}
                      {participant.termsAndConditionsSigned === true ? (
                        <td>T&C</td>
                      ) : (
                        <td></td>
                      )}

                      {participant.loginToGm === true ? (
                        <td class="text-center">
                          <i class="fa fa-circle online" aria-hidden="true"></i>
                        </td>
                      ) : (
                        <td></td>
                      )}

                    
                      <td >
                        <div class=" d-flex justify-content-center">
                          <div>
                          <a
                          href="#"
                          class="btn btn-sm btn-secondary "
                          data-toggle="modal"
                          data-target="#uploadModal"
                          onClick={() => this.handleShow(participant)}
                        >
                          <i class="fa fa-cloud-upload" aria-hidden="true"></i>
                        </a>

                          </div>
                          <div>
                          <Link
                          class="btn btn-sm btn-info "
                          onClick={() => this.handleUpdateShow(participant)}
                        >
                          <i class="fa fa-pencil" aria-hidden="true"></i>
                        </Link>

                          </div>
                          <div>
                          {participant.enrolStatus === 0 ||
                        participant.enrolStatus === null ? (
                          <a
                            href="#"
                            class="btn btn-sm  disabled"
                            style={{ backgroundColor: "purple" }}
                            onClick={() =>
                              this.handleSendEmailShow(participant)
                            }
                          >
                            <i
                              class="fa fa-envelope"
                              style={{ color: "white" }}
                              aria-hidden="true"
                            ></i>
                          </a>
                        ) : (
                          <div class=""></div>
                        )}
                          </div>
                        </div>
                        
                        


                       
                      </td>
                    
                      </>:<></>

                      }
                    </tr>
                  ))
                )}
              </tbody>
            </table>
            <div className="pager">
              <div className="pagination" >
                {/* <Pagination>
                  <Pagination.Prev onClick={this.limitPrev} hidden={this.limit==0 ?true:false}/>
                 

                  <Pagination.Next onClick={this.limitNext} hidden={errorMsg?true:false || list.length<20?true:false}/>
                   
                </Pagination> */}
                  <Pagination
                    activePage={this.props.lastState?.activePage || this.state.activePage} 
                    itemClass="page-item"
                    linkClass="page-link"
                    itemsCountPerPage={20}
                    totalItemsCount={this.state.totalCount}
                    pageRangeDisplayed={5}
                    onChange={this.handlePageChange}
        />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const commonTabs = withTranslation()(CommonTabs);

export default commonTabs;
