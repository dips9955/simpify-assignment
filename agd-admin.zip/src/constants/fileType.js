export const FILETYPE =[
    { id:4 ,    fileType_name: "selfie-ID",             icon:"fa fa-id-card-o"},
    { id:5 ,    fileType_name: "Attestation de participation", icon:"fa fa-file-o"},
    { id:6 ,    fileType_name: "KBis",                  icon:"fa fa-file-image-o"},
    { id:7 ,    fileType_name: "Signed Power Attorney", icon:"fa fa-file-pdf-o"},
    { id:12,    fileType_name: "Audio file",           icon:"fa fa-volume-down"},
    { id:13 ,   fileType_name: "Video file",           icon:"fa fa-video-camera"}
] 