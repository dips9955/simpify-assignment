import {  toast } from 'react-toastify';
import axios from "axios";
import config from "../config/index";

const  {API_BASE_URL} = config;

export const handleError = (err,props) => {
        console.log("error props",props)
        if (
         err.response &&
         err.response.data &&
         err.response.data.responseMessage
       ) {
         console.log("error in reponse");
         if(err.response &&
          err.response.data &&
          err.response.data.responseMessage&&err.response.data.responseStatus==408 || err.response &&
          err.response.data &&
          err.response.data.responseMessage&&err.response.data.responseStatus==401){
            console.log("dddd",atob(localStorage.getItem('staffData')))
            console.log("click");
           
        
            axios({
              method: "post",
              url: API_BASE_URL + "user/logout",
              headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                Pragma: 'no-cache'
              },
              data: {
                meetingId:atob(localStorage.getItem('meetingId')),
                email: atob(localStorage.getItem('email')),
              },
            })
              .then((response) => {
                console.log(response.data);
                localStorage.clear()
                toast.success("Déconnexion réussie", {
                  position: toast.POSITION.TOP_RIGHT,
                  toastId: 8,
                  autoClose: 3000
                });
               props.history.push("/")
                
              })
              .catch(err.response.data.responseMessage);
        
         }
         toast.error(err.response.data.responseMessage, {
           position: toast.POSITION.TOP_RIGHT,
           toastId: 2,
           autoClose: 3000
         });
       } else if (err.request) {
         console.log("error in request");
         toast.error("Souci de connexion au serveur", {
           position: toast.POSITION.TOP_RIGHT,
           toastId: 3,
           autoClose: 3000
         });
       } else {
         console.log(err);
       }
       };
      
      
      
      
       export const handleGetlistError = (err,props) => {
        console.log("error props",props)
        if(  err.response &&
          err.response.data &&
          err.response.data.responseMessage&&err.response.data.responseStatus==404){
          console.log("record not found")
        }
        else if( err.response &&
          err.response.data &&
          err.response.data.responseMessage&&err.response.data.responseStatus==408 || err.response &&
          err.response.data &&
          err.response.data.responseMessage&&err.response.data.responseStatus==401){
            console.log("dddd",atob(localStorage.getItem('staffData')))
            console.log("click");
           
        
            axios({
              method: "post",
              url: API_BASE_URL + "user/logout",
              headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                Pragma: 'no-cache'
              },
              data: {
                meetingId:atob(localStorage.getItem('meetingId')),
                email: atob(localStorage.getItem('email')),
              },
            })
              .then((response) => {
                console.log(response.data);
                localStorage.clear()
                toast.success("Déconnexion réussie", {
                  position: toast.POSITION.TOP_RIGHT,
                  toastId: 8,
                  autoClose: 3000
                });
               props.history.push("/")
                
              })
              .catch(err.response.data.responseMessage);
        
         }
         else  if (
          err.response &&
          err.response.data &&
          err.response.data.responseMessage
        ) {
          console.log("error in reponse");
          toast.error(err.response.data.responseMessage, {
            position: toast.POSITION.TOP_RIGHT,
            toastId: 2,
            autoClose: 3000
          });
        }
        else if (err.request) {
         console.log("error in request");
         toast.error("Souci de connexion au serveur", {
           position: toast.POSITION.TOP_RIGHT,
           toastId: 3,
           autoClose: 3000
         });
       } else {
         console.log(err);
       }
       };
