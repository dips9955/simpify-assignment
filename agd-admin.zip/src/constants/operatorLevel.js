export const ENROLOPERATORLEVEL =[
  {id:0,level:"ALL"},
    {id:1,level:"L1"},
    {id:2,level:"L2"},
  ]