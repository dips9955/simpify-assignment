    export const TITLE = [
    {id:1	,title:"Société"},
    {id:2	,title:"Correspondant"},
    {id:3	,title:"Monsieur"},
    {id:4	,title:"Madame"},
    {id:5	,title:"Mademoiselle"},
    {id:6	,title:"Monsieur et Madame"},
    {id:7	,title:"Monsieur ou Madame"},
    {id:8	,title:"Maître"},
    {id:9	,title:"Club d'investissement"},
    {id:10	,title:"Portfolio"},
    {id:11	,title:"Succession"},
    {id:12	,title:"Indivision"},
    {id:13	,title:"Autre"}
    ]