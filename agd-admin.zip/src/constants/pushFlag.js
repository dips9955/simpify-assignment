export const PUSH =[
    {id:1,pushFlag:  "Email"}, 
    {id:2,pushFlag:  "Web"}, 
    {id:3,pushFlag:  "Web+Email"},
]