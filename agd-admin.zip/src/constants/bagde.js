export const BADGE = [
        {id:1	,p_typeName:"Admission card",badge_name:"AC" ,badge_frenchName:"CA"},
        {id:2	,p_typeName:"No Admission card",badge_name:"NC" ,badge_frenchName:"NC"},
        {id:3	,p_typeName:"Vote by mail",badge_name:"Mail" ,badge_frenchName:"VpC"},
        {id:4	,p_typeName:"Chairman of the meeting",badge_name:"CH" ,badge_frenchName:"PR"},
        {id:5	,p_typeName:"Archive",badge_name:"AR" ,badge_frenchName:"AR"},
        {id:6	,p_typeName:"Nominative",badge_name:"UN",badge_frenchName:"NS"},
        {id:7	,p_typeName:"Proxy to the president",badge_name:"PP",badge_frenchName:"PP"},
        {id:8	,p_typeName:"Proxy to third party",badge_name:"PT",badge_frenchName:"PT"},
        {id:9	,p_typeName:"Proxy to president in case of absence",badge_name:"PPA" ,badge_frenchName:"PPA"},
        {id:10  ,p_typeName:"Proxy to third party in case of absence",badge_name:"PTA" ,badge_frenchName:"PTA"},
        {id:11  ,p_typeName:"Unexpected bearer shareholder",badge_name:"UB" ,badge_frenchName:"PS"}
]










