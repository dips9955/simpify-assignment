import React from 'react'
import {  toast } from 'react-toastify';
import axios from "axios";
import config from "../config/index";
import history from "../services/history"

const  {API_BASE_URL} = config;

const logout=(props)=> {
    debugger
    axios({
        method: "post",
        url: API_BASE_URL + "user/logout",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Pragma: 'no-cache'
        },
        data: {
          meetingId:atob(localStorage.getItem('meetingId')),
          email: atob(localStorage.getItem('email')),
        },
      })
        .then((response) => {
          console.log(response.data);
          localStorage.clear()
          toast.susscess("Logout Successful", {
            position: toast.POSITION.TOP_RIGHT,
            autoClose: 3000
          });
          history.push("/");
          
        })
        .catch();
  
}

export default logout
