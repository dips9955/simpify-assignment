export const ACTIONS =[
{id:1 , actionName:"envelope", class_name:"btn-warning", pageCode:1 ,enrolStatus:3},
{id:2 , actionName:"id-card", class_name:"btn-dark", pageCode:2 ,enrolStatus:3},
{id:4 , actionName:"address-card", class_name:"btn-success", pageCode:2 ,enrolStatus:3},
{id:3 , actionName:"file", class_name:"btn-info", pageCode:1 ,enrolStatus:3},
{id:5 , actionName:"id-card", class_name:"btn-dark", pageCode:1 ,enrolStatus:3},

]