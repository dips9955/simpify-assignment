export const ENROLSTATUS = [
    {id:0, status_name: "Autre"}, 
    {id:1, status_name: "Au début "}, 
    {id:2, status_name: "En cours"}, 
    {id:3, status_name: "Validé"}, 
    {id:4, status_name: "En attente"}, 
    {id:5, status_name: "En attente de T&C"}, 
    {id:6, status_name: "T&C signé"}
]